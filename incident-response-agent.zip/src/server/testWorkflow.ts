import { incidentMemoryStore } from './vectorStore';
import { incidentAIOrchestrator } from './aiOrchestrator';
import { Incident, IncidentMemory } from '../types/incident';

async function runTestSuite() {
  console.log('🧪 Starting Incident Response Agent Test Suite...\n');

  let passed = 0;
  let total = 0;

  function assert(condition: boolean, message: string) {
    total++;
    if (condition) {
      console.log(`  ✓ [PASS] ${message}`);
      passed++;
    } else {
      console.error(`  ✗ [FAIL] ${message}`);
      process.exitCode = 1;
    }
  }

  // Test 1: Seed data initialization
  console.log('1. Verifying Vector Store Seed Data Initialization:');
  const initialMemories = await incidentMemoryStore.listIncidents();
  assert(initialMemories.length >= 12, `Vector store contains ${initialMemories.length} historical memories (expected >= 12)`);
  assert(initialMemories.some(m => m.id === 'mem-001'), 'Contains primary demo memory mem-001 (Payment API connection pool)');

  // Test 2: Vector Similarity Search
  console.log('\n2. Testing Vector Similarity Retrieval:');
  const query = 'Payment API returning 500 errors Database connection pool exhausted sqlalchemy.exc.TimeoutError QueuePool limit';
  const similar = await incidentMemoryStore.searchSimilarIncidents(query, 5);
  assert(similar.length > 0, `Retrieved ${similar.length} similar incidents`);
  assert(similar[0].memoryId === 'mem-001', `Top match is mem-001 (actual: ${similar[0]?.memoryId})`);
  assert(similar[0].similarityScore >= 0.85, `Similarity score is >= 85% (actual: ${Math.round(similar[0].similarityScore * 100)}%)`);

  // Test 3: AI Orchestrator Analysis & Remediation Generation
  console.log('\n3. Testing AI Orchestrator Analysis & Remediation Plan:');
  const testIncident: Incident = {
    id: 'test-inc-1',
    title: 'Payment API database connection pool exhausted',
    severity: 'SEV-1',
    service: 'payment-api',
    environment: 'Production',
    description: 'All payments failing with 500 status',
    logs: 'ERROR sqlalchemy.exc.TimeoutError: QueuePool limit of size 100 overflow 0 reached',
    alertSource: 'Datadog',
    status: 'detected',
    createdAt: new Date().toISOString(),
    detectedSymptoms: [],
    timeline: []
  };

  const analysis = await incidentAIOrchestrator.analyzeIncident(testIncident);
  assert(analysis.detectedSymptoms.length > 0, `Detected symptoms: ${analysis.detectedSymptoms.join(', ')}`);
  assert(analysis.probableRootCause.confidence >= 0.8, `Root cause confidence is >= 80% (actual: ${analysis.probableRootCause.confidence})`);
  assert(analysis.remediationStages.length >= 4, `Generated 4-stage remediation plan (actual: ${analysis.remediationStages.length})`);
  assert(!!analysis.recommendedRunbook, `Recommended runbook: ${analysis.recommendedRunbook.name}`);
  assert(analysis.similarIncidents.length > 0, `RAG evidence includes ${analysis.similarIncidents.length} similar incidents`);

  // Test 4: End-to-End Feedback Loop & Continuous Learning
  console.log('\n4. Testing Learning Feedback Loop (Resolve -> Vector Index -> Retrieve):');
  const customLearnedTitle = 'Custom Hotfix v2.4.9 for Redis Sentinel Split-Brain in Payment Cluster';
  const newMemoryToLearn: IncidentMemory = {
    id: `mem-test-learned-${Date.now()}`,
    incidentTitle: customLearnedTitle,
    service: 'payment-api',
    severity: 'SEV-1',
    environment: 'Production',
    symptoms: ['Redis sentinel split brain', 'payment-api cache desync', 'inconsistent balance reads'],
    rootCause: 'Network partition between sentinel node 1 and 2 led to dual master promotion',
    rootCauseCategory: 'Infrastructure',
    resolution: 'Enforced min-replicas-to-write 2 and reconfigured sentinel quorum to 2/3',
    runbook: 'Redis Cluster Failover & Pool Reset',
    resolutionSuccessful: true,
    timeToResolutionMinutes: 8,
    engineerFeedback: 'Sentinel quorum fix completely prevented dual master election',
    createdAt: new Date().toISOString(),
    isLiveLearned: true
  };

  // Add new learned memory to vector database
  await incidentMemoryStore.addIncident(newMemoryToLearn);
  const updatedMemories = await incidentMemoryStore.listIncidents();
  assert(updatedMemories.length === initialMemories.length + 1, 'Memory store size increased by 1');

  // Query specifically for the newly learned incident
  const learnedQuery = 'payment-api Redis sentinel split brain dual master promotion';
  const retrievedAfterLearning = await incidentMemoryStore.searchSimilarIncidents(learnedQuery, 3);
  assert(retrievedAfterLearning[0].title === customLearnedTitle, `Newly learned incident retrieved as #1 match: "${retrievedAfterLearning[0]?.title}"`);
  assert(retrievedAfterLearning[0].isLiveLearned === true, 'Retrieved incident is marked with isLiveLearned: true');
  assert(retrievedAfterLearning[0].similarityScore >= 0.85, `Similarity score: ${Math.round(retrievedAfterLearning[0].similarityScore * 100)}%`);

  console.log(`\n🎉 Test Suite Completed: ${passed} / ${total} tests passed!`);
  if (passed !== total) {
    process.exit(1);
  }
}

runTestSuite().catch(err => {
  console.error('Test suite failed with exception:', err);
  process.exit(1);
});
