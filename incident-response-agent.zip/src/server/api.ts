import { Router } from 'express';
import { Incident, PostMortem, IncidentMemory } from '../types/incident';
import { INITIAL_ACTIVE_INCIDENTS, INITIAL_RUNBOOKS } from './seedData';
import { incidentMemoryStore } from './vectorStore';
import { incidentAIOrchestrator } from './aiOrchestrator';

export const apiRouter = Router();

// In-memory incidents storage
let liveIncidents: Incident[] = [...INITIAL_ACTIVE_INCIDENTS];

// GET /api/metrics
apiRouter.get('/metrics', async (req, res) => {
  const memories = await incidentMemoryStore.listIncidents();
  const totalIncidents = 142 + (liveIncidents.length - 1);
  const activeCount = liveIncidents.filter(i => i.status !== 'resolved').length;
  const resolvedCount = totalIncidents - activeCount;

  res.json({
    totalIncidents,
    activeIncidents: activeCount,
    resolvedIncidents: resolvedCount,
    averageResolutionTime: '18m',
    historicalMemories: memories.length,
    successfulRunbooks: 42,
    aiAssistedResolutionRate: '87%',
    vectorIndexType: '384-dim Dense Cosine + BM25',
    activeModel: process.env.GEMINI_API_KEY ? 'gemini-3.8-flash' : 'sre-deterministic-engine'
  });
});

// GET /api/incidents
apiRouter.get('/incidents', (req, res) => {
  res.json(liveIncidents);
});

// POST /api/incidents
apiRouter.post('/incidents', (req, res) => {
  const { title, severity, service, environment, description, logs, alertSource } = req.body;

  if (!title || !service) {
    res.status(400).json({ error: 'Title and service are required' });
    return;
  }

  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const newIncident: Incident = {
    id: `inc-${Date.now()}`,
    title,
    severity: severity || 'SEV-2',
    service,
    environment: environment || 'Production',
    description: description || '',
    logs: logs || '',
    alertSource: alertSource || 'Manual',
    status: 'detected',
    createdAt: now.toISOString(),
    detectedSymptoms: [],
    timeline: [
      {
        id: `tl-${Date.now()}-1`,
        timestamp: now.toISOString(),
        timeDisplay: timeStr,
        title: 'Incident Detected',
        description: `Alert logged from ${alertSource || 'Manual'} for ${service}.`,
        type: 'detection'
      }
    ],
    isLiveCreated: true
  };

  liveIncidents.unshift(newIncident);
  res.status(201).json(newIncident);
});

// GET /api/incidents/:id
apiRouter.get('/incidents/:id', (req, res) => {
  const incident = liveIncidents.find(i => i.id === req.params.id);
  if (!incident) {
    res.status(404).json({ error: 'Incident not found' });
    return;
  }
  res.json(incident);
});

// POST /api/incidents/:id/analyze
apiRouter.post('/incidents/:id/analyze', async (req, res) => {
  const incidentIndex = liveIncidents.findIndex(i => i.id === req.params.id);
  if (incidentIndex === -1) {
    res.status(404).json({ error: 'Incident not found' });
    return;
  }

  const current = liveIncidents[incidentIndex];
  try {
    const analysis = await incidentAIOrchestrator.analyzeIncident(current);

    // Merge analysis into current incident
    const updated: Incident = {
      ...current,
      status: current.status === 'resolved' ? 'resolved' : 'action_required',
      detectedSymptoms: analysis.detectedSymptoms,
      errorType: analysis.errorType,
      probableRootCause: analysis.probableRootCause,
      similarIncidents: analysis.similarIncidents,
      reasoningContext: analysis.reasoningContext,
      remediationStages: analysis.remediationStages,
      recommendedRunbook: analysis.recommendedRunbook,
      timeline: analysis.timeline
    };

    liveIncidents[incidentIndex] = updated;

    res.json({
      incident: updated,
      activitySteps: analysis.activitySteps,
      providerUsed: analysis.providerUsed
    });
  } catch (err: any) {
    console.error('Analysis error:', err);
    res.status(500).json({ error: err.message || 'Failed to analyze incident' });
  }
});

// GET /api/incidents/:id/similar
apiRouter.get('/incidents/:id/similar', async (req, res) => {
  const incident = liveIncidents.find(i => i.id === req.params.id);
  if (!incident) {
    res.status(404).json({ error: 'Incident not found' });
    return;
  }

  const query = `${incident.title} ${incident.service} ${incident.description} ${incident.logs}`;
  const similar = await incidentMemoryStore.searchSimilarIncidents(query, 5);
  res.json(similar);
});

// POST /api/incidents/:id/step
apiRouter.post('/incidents/:id/step', (req, res) => {
  const incident = liveIncidents.find(i => i.id === req.params.id);
  if (!incident || !incident.remediationStages) {
    res.status(404).json({ error: 'Incident or remediation plan not found' });
    return;
  }

  const { stepId, completed } = req.body;
  let found = false;

  for (const stage of incident.remediationStages) {
    for (const step of stage.steps) {
      if (step.id === stepId) {
        step.completed = completed !== undefined ? completed : !step.completed;
        found = true;
        break;
      }
    }
  }

  if (!found) {
    res.status(404).json({ error: 'Step not found' });
    return;
  }

  res.json(incident);
});

// POST /api/incidents/:id/simulate
apiRouter.post('/incidents/:id/simulate', (req, res) => {
  const incident = liveIncidents.find(i => i.id === req.params.id);
  if (!incident) {
    res.status(404).json({ error: 'Incident not found' });
    return;
  }

  const service = incident.service || 'payment-api';
  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const simulationLogs = [
    {
      command: `kubectl rollout history deployment/${service} -n production`,
      outputLines: [
        `deployment.apps/${service}`,
        `REVISION  CHANGE-CAUSE`,
        `40        v2.4.0 (stable release tag)`,
        `41        v2.4.1 (feature: async transaction telemetry logger)`
      ],
      status: 'success' as const
    },
    {
      command: `kubectl rollout undo deployment/${service} -n production`,
      outputLines: [
        `Checking deployment revision history...`,
        `✓ Previous stable version revision 40 found (v2.4.0)`,
        `deployment.apps/${service} rollback to revision 40 initiated.`
      ],
      status: 'success' as const
    },
    {
      command: `kubectl rollout status deployment/${service} -n production --timeout=90s`,
      outputLines: [
        `Waiting for deployment "${service}" rollout to finish: 1 out of 3 new replicas updated...`,
        `Waiting for deployment "${service}" rollout to finish: 2 out of 3 new replicas updated...`,
        `Waiting for deployment "${service}" rollout to finish: 3 out of 3 new replicas updated...`,
        `✓ deployment "${service}" successfully rolled out.`
      ],
      status: 'success' as const
    },
    {
      command: `kubectl get pods -n production -l app=${service}`,
      outputLines: [
        `NAME                           READY   STATUS    RESTARTS   AGE`,
        `${service}-7b8c8d8b6-x4m21    1/1     Running   0          24s`,
        `${service}-7b8c8d8b6-9zq10    1/1     Running   0          21s`,
        `${service}-7b8c8d8b6-lp33a    1/1     Running   0          18s`,
        ``,
        `✓ Verification: HTTP 500 error rate dropped: 48.2% -> 0.02%`,
        `✓ Active DB connections recovered: 100/100 -> 24/100`,
        `✓ Latency p99 restored: 10,240ms -> 114ms`
      ],
      status: 'success' as const
    }
  ];

  incident.simulationResults = simulationLogs;
  incident.status = 'mitigating';

  // Add timeline entry
  incident.timeline.push({
    id: `tl-sim-${Date.now()}`,
    timestamp: now.toISOString(),
    timeDisplay: timeStr,
    title: 'Runbook Simulation Executed',
    description: `Automated simulation of ${incident.recommendedRunbook?.name || 'Recovery Runbook'} completed. Pod rollback and error recovery verified.`,
    type: 'simulation'
  });

  // Mark immediate steps as completed in Stage 1
  if (incident.remediationStages && incident.remediationStages[0]) {
    incident.remediationStages[0].steps.forEach(s => {
      s.completed = true;
    });
  }

  res.json({
    incident,
    simulationLogs
  });
});

// POST /api/incidents/:id/resolve (The Critical Learning & Feedback Loop)
apiRouter.post('/api/incidents/:id/resolve', async (req, res) => {
  // Handled by resolve handler below
});

apiRouter.post('/incidents/:id/resolve', async (req, res) => {
  const incidentIndex = liveIncidents.findIndex(i => i.id === req.params.id);
  if (incidentIndex === -1) {
    res.status(404).json({ error: 'Incident not found' });
    return;
  }

  const {
    actualFix,
    utilityRating,
    actualRootCause,
    agentMemoryTakeaway,
    resolutionTimeMinutes
  } = req.body;

  const incident = liveIncidents[incidentIndex];
  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const postMortem: PostMortem = {
    actualFix: actualFix || 'Deployment rolled back to previous stable release and pods restarted.',
    utilityRating: utilityRating || 'Very useful',
    actualRootCause: actualRootCause || incident.probableRootCause?.description || 'Connection pool exhaustion',
    agentMemoryTakeaway: agentMemoryTakeaway || 'Remember to verify session cleanup in all async transaction handlers.',
    resolvedAt: now.toISOString(),
    timeToResolutionMinutes: resolutionTimeMinutes || 7,
    resolutionSuccessful: true
  };

  // Update incident status
  incident.status = 'resolved';
  incident.resolvedAt = now.toISOString();
  incident.postMortem = postMortem;

  // Add timeline event
  incident.timeline.push({
    id: `tl-res-${Date.now()}`,
    timestamp: now.toISOString(),
    timeDisplay: timeStr,
    title: 'Incident Resolved & Learned',
    description: `Post-mortem indexed into memory store. Resolution time: ${postMortem.timeToResolutionMinutes} mins.`,
    type: 'resolved'
  });

  // Construct structured memory object (Requirement 14)
  const newMemory: IncidentMemory = {
    id: `mem-${Date.now()}`,
    incidentId: incident.id,
    incidentTitle: incident.title,
    service: incident.service,
    severity: incident.severity,
    environment: incident.environment,
    symptoms: incident.detectedSymptoms.length > 0 ? incident.detectedSymptoms : [incident.description],
    rootCause: postMortem.actualRootCause,
    rootCauseCategory: incident.service.includes('payment') ? 'Database' : 'Application',
    resolution: postMortem.actualFix,
    runbook: incident.recommendedRunbook?.name || 'DB Connection Pool Recovery',
    runbookCommands: incident.recommendedRunbook?.commands || [],
    resolutionSuccessful: true,
    timeToResolutionMinutes: postMortem.timeToResolutionMinutes,
    engineerFeedback: `${utilityRating} rating. ${agentMemoryTakeaway}`,
    createdAt: now.toISOString(),
    isLiveLearned: true
  };

  // Save to vector database with fresh embedding!
  await incidentMemoryStore.addIncident(newMemory);

  res.json({
    incident,
    createdMemory: newMemory,
    message: 'Post-mortem successfully saved to organizational vector memory.'
  });
});

// GET /api/memory
apiRouter.get('/memory', async (req, res) => {
  const { query, service, severity, category, successOnly } = req.query;
  let list = await incidentMemoryStore.listIncidents();

  if (query && typeof query === 'string') {
    const qLower = query.toLowerCase();
    list = list.filter(m =>
      m.incidentTitle.toLowerCase().includes(qLower) ||
      m.service.toLowerCase().includes(qLower) ||
      m.rootCause.toLowerCase().includes(qLower) ||
      m.resolution.toLowerCase().includes(qLower)
    );
  }

  if (service && typeof service === 'string') {
    list = list.filter(m => m.service.toLowerCase() === service.toLowerCase());
  }

  if (severity && typeof severity === 'string') {
    list = list.filter(m => m.severity === severity);
  }

  if (category && typeof category === 'string') {
    list = list.filter(m => m.rootCauseCategory.toLowerCase() === category.toLowerCase());
  }

  if (successOnly === 'true') {
    list = list.filter(m => m.resolutionSuccessful);
  }

  res.json(list);
});

// GET /api/memory/:id
apiRouter.get('/memory/:id', async (req, res) => {
  const memory = await incidentMemoryStore.getIncident(req.params.id);
  if (!memory) {
    res.status(404).json({ error: 'Memory not found' });
    return;
  }
  res.json(memory);
});

// POST /api/memory
apiRouter.post('/memory', async (req, res) => {
  const memory: IncidentMemory = {
    ...req.body,
    id: `mem-${Date.now()}`,
    createdAt: new Date().toISOString(),
    isLiveLearned: true
  };
  await incidentMemoryStore.addIncident(memory);
  res.status(201).json(memory);
});

// GET /api/runbooks
apiRouter.get('/runbooks', (req, res) => {
  res.json(INITIAL_RUNBOOKS);
});

// POST /api/reset
apiRouter.post('/reset', async (req, res) => {
  await incidentMemoryStore.resetToSeed();
  liveIncidents = [...INITIAL_ACTIVE_INCIDENTS];
  res.json({ message: 'Memory and incidents reset to initial seed state' });
});
