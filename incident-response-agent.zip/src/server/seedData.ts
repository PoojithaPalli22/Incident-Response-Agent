import { IncidentMemory, RecommendedRunbook, Incident } from '../types/incident';

export const INITIAL_RUNBOOKS: RecommendedRunbook[] = [
  {
    id: 'rb-db-pool',
    name: 'DB Connection Pool Recovery',
    description: 'Procedure to mitigate and resolve database connection pool saturation, connection leaks, and queue pool timeouts.',
    targetService: 'payment-api',
    successRate: 0.96,
    warning: '⚠ These commands are suggestions generated from historical runbooks. Review them before executing against production.',
    steps: [
      'Inspect current active vs idle connections in PostgreSQL/pgBouncer',
      'Identify offending deployment revision and check rollout history',
      'Execute rollback to the previous known stable deployment artifact',
      'Perform rolling restart of affected service pods to release orphaned connections',
      'Verify pool metrics drop below 40% and error rate returns to baseline'
    ],
    commands: [
      'kubectl rollout history deployment/payment-api -n production',
      'kubectl rollout undo deployment/payment-api -n production',
      'kubectl rollout status deployment/payment-api -n production --timeout=90s',
      'kubectl get pods -n production -l app=payment-api -o wide',
      'kubectl top pods -n production -l app=payment-api'
    ]
  },
  {
    id: 'rb-k8s-crashloop',
    name: 'Kubernetes Pod Crash Recovery',
    description: 'Diagnostic and remediation runbook for CrashLoopBackOff, OOMKilled, and failing liveness/readiness probes.',
    targetService: 'payment-service',
    successRate: 0.92,
    warning: '⚠ Restarting pods or altering resource limits may cause transient latency. Ensure healthy replicas remain available.',
    steps: [
      'Inspect pod termination reason and exit codes (e.g. 137 OOMKilled)',
      'Review previous pod container logs prior to termination',
      'Temporarily increase container memory limit or rollback faulty image',
      'Verify readiness probe passes and restarts cease'
    ],
    commands: [
      'kubectl describe pod -l app=payment-service -n production | grep -E "Terminated|Exit Code|Reason"',
      'kubectl logs -l app=payment-service -n production --previous --tail=100',
      'kubectl rollout undo deployment/payment-service -n production',
      'kubectl get pods -l app=payment-service -n production -w'
    ]
  },
  {
    id: 'rb-redis-timeout',
    name: 'Redis Cluster Failover & Pool Reset',
    description: 'Runbook to recover from Redis connection pool exhaustion, cluster node partitions, and unreleased client sockets.',
    targetService: 'auth-service',
    successRate: 0.89,
    warning: '⚠ Resetting connections will invalidate unpersisted session caches. Ensure session database handles re-auth gracefully.',
    steps: [
      'Check Redis latency and connected clients count via redis-cli info',
      'Kill idling client connections older than 300 seconds',
      'Trigger cluster failover if primary node is non-responsive',
      'Restart service pods to establish clean connection pools'
    ],
    commands: [
      'redis-cli -h redis-cluster.production.internal info clients',
      'redis-cli -h redis-cluster.production.internal CLIENT KILL TYPE normal IDLE 300',
      'kubectl rollout restart deployment/auth-service -n production',
      'kubectl rollout status deployment/auth-service -n production'
    ]
  },
  {
    id: 'rb-kafka-lag',
    name: 'Kafka Consumer Lag & Poison Pill Mitigation',
    description: 'Procedure to resolve Kafka consumer group starvation and poison pill message blocks.',
    targetService: 'notification-worker',
    successRate: 0.94,
    warning: '⚠ Skipping offsets drops unhandled messages to the dead letter queue (DLQ). Verify DLQ consumer is active.',
    steps: [
      'Inspect consumer group offsets and identify lagging partition',
      'Extract poison pill message payload causing deserialization crash',
      'Route poison pill to Dead Letter Queue (DLQ)',
      'Reset consumer offset forward by 1 message and resume consumption'
    ],
    commands: [
      'kafka-consumer-groups.sh --bootstrap-server kafka:9092 --describe --group notification-workers',
      'kubectl logs -l app=notification-worker -n production --tail=50 | grep "DeserializationError"',
      'kubectl rollout restart deployment/notification-worker -n production'
    ]
  }
];

export const INITIAL_HISTORICAL_MEMORIES: IncidentMemory[] = [
  {
    id: 'mem-001',
    incidentTitle: 'Payment API database connection pool exhaustion',
    service: 'payment-api',
    severity: 'SEV-1',
    environment: 'Production',
    symptoms: [
      'HTTP 500 Internal Server Error spike',
      'QueuePool limit of size 100 overflow 0 reached',
      'payment-api response latency > 10 seconds',
      'Active database connections pegged at 100/100'
    ],
    rootCause: 'Database connection leak introduced in deployment v2.4.1 where transaction contexts failed to close SQLAlchemy sessions on payment failure routes.',
    rootCauseCategory: 'Database',
    resolution: 'Rolled back deployment to v2.4.0 and executed rolling restart on all payment-api pods to terminate orphaned pool connections.',
    runbook: 'DB Connection Pool Recovery',
    runbookCommands: [
      'kubectl rollout undo deployment/payment-api -n production',
      'kubectl rollout status deployment/payment-api -n production',
      'kubectl get pods -l app=payment-api'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 7,
    engineerFeedback: 'Immediate rollback to v2.4.0 freed all 100 connections instantly. Hotfix patch v2.4.2 was released 2 hours later with explicit context-manager session cleanup.',
    createdAt: '2026-08-14T10:15:00Z'
  },
  {
    id: 'mem-002',
    incidentTitle: 'Order Service database saturation',
    service: 'order-service',
    severity: 'SEV-2',
    environment: 'Production',
    symptoms: [
      'High database CPU utilization (>95%)',
      'Connection starvation on read-write replicas',
      'Order checkout request timeouts (>30s)',
      'QueuePool connection acquire timeout'
    ],
    rootCause: 'Unindexed reporting query executed by bulk exporter held table-level shared locks, causing connection starvation across online ordering pools.',
    rootCauseCategory: 'Database',
    resolution: 'Terminated long-running query PID in PostgreSQL, increased pool acquire timeout temporarily, and routed reporting queries to dedicated read replica.',
    runbook: 'DB Connection Pool Recovery',
    runbookCommands: [
      "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state = 'active' AND query_start < NOW() - INTERVAL '5 minutes';",
      'kubectl rollout restart deployment/order-service -n production'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 12,
    engineerFeedback: 'Terminating the long-running analytical query instantly unblocked the pool. Added pg_stat_statements alert for queries exceeding 2 seconds.',
    createdAt: '2026-07-22T16:40:00Z'
  },
  {
    id: 'mem-003',
    incidentTitle: 'Payment API latency after deployment',
    service: 'payment-api',
    severity: 'SEV-1',
    environment: 'Production',
    symptoms: [
      'Payment API p99 latency increased to 14.2s',
      'Postgres connection count steadily increasing linearly',
      '504 Gateway Timeouts at Cloudflare reverse proxy',
      'sqlalchemy.exc.TimeoutError connection timed out'
    ],
    rootCause: 'New code path in payment receipt generation omitted db.session.close() in an asynchronous callback, causing slow leak over 45 minutes.',
    rootCauseCategory: 'Application',
    resolution: 'Rollback deployment to previous stable tag and patched session lifecycle handling with try...finally cleanup wrapper.',
    runbook: 'DB Connection Pool Recovery',
    runbookCommands: [
      'kubectl rollout undo deployment/payment-api -n production',
      'kubectl get pods -l app=payment-api -n production'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 9,
    engineerFeedback: 'Rollback was the fastest way to alleviate user-facing payment checkout errors. Code audit confirmed session scope leak.',
    createdAt: '2026-06-03T11:20:00Z'
  },
  {
    id: 'mem-004',
    incidentTitle: 'Payment Service Kubernetes CrashLoopBackOff',
    service: 'payment-service',
    severity: 'SEV-1',
    environment: 'Production',
    symptoms: [
      'Pod status CrashLoopBackOff with ExitCode 137',
      'Kubernetes OOMKilled events on payment-service-worker',
      'Elevated payment queuing latency'
    ],
    rootCause: 'JVM max heap parameter (-Xmx) was set higher than the Kubernetes container memory limit in deployment spec, leading Linux kernel cgroup killer to terminate the container.',
    rootCauseCategory: 'Kubernetes',
    resolution: 'Adjusted JVM ergonomics to use -XX:MaxRAMPercentage=75.0 and rolled back deployment spec, then restarted worker pods.',
    runbook: 'Kubernetes Pod Crash Recovery',
    runbookCommands: [
      'kubectl rollout undo deployment/payment-service -n production',
      'kubectl get pods -l app=payment-service -n production'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 11,
    engineerFeedback: 'Pods stabilized immediately once container limits matched JVM cgroup parameters.',
    createdAt: '2026-08-30T14:05:00Z'
  },
  {
    id: 'mem-005',
    incidentTitle: 'Auth Service Redis connection timeout spike',
    service: 'auth-service',
    severity: 'SEV-2',
    environment: 'Production',
    symptoms: [
      'User login requests failing with 500 error',
      'Redis connection pool exhausted (max 500 clients)',
      'SocketTimeoutException on token verification',
      'Redis cluster primary node failover in progress'
    ],
    rootCause: 'Redis cluster failover caused TCP connections to become half-open; auth-service client driver lacked TCP keepalive and hung until connection pool hit ceiling.',
    rootCauseCategory: 'Infrastructure',
    resolution: 'Killed zombie connections using redis-cli CLIENT KILL and triggered rolling restart of auth-service with TCP keepalive enabled.',
    runbook: 'Redis Cluster Failover & Pool Reset',
    runbookCommands: [
      'redis-cli CLIENT KILL TYPE normal IDLE 120',
      'kubectl rollout restart deployment/auth-service -n production'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 14,
    engineerFeedback: 'Restarting auth-service pods flushed client socket tables and restored login traffic.',
    createdAt: '2026-05-18T08:50:00Z'
  },
  {
    id: 'mem-006',
    incidentTitle: 'Checkout Service HTTP 500 error spike',
    service: 'checkout-service',
    severity: 'SEV-1',
    environment: 'Production',
    symptoms: [
      'HTTP 500 error rate surged to 38%',
      'Downstream payment gateway webhook timeouts',
      'Thread pool exhaustion on checkout worker'
    ],
    rootCause: 'External payment partner API had increased latency; checkout-service lacked circuit breaking, causing all worker threads to block waiting for upstream HTTP response.',
    rootCauseCategory: 'Application',
    resolution: 'Enabled circuit breaker fallback with 3-second timeout and queued transactions for asynchronous retry.',
    runbook: 'DB Connection Pool Recovery',
    runbookCommands: [
      'kubectl set env deployment/checkout-service CIRCUIT_BREAKER_ENABLED=true -n production',
      'kubectl rollout restart deployment/checkout-service -n production'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 16,
    engineerFeedback: 'Circuit breaker isolated the third-party outage and allowed graceful fallback message to shoppers.',
    createdAt: '2026-04-12T19:30:00Z'
  },
  {
    id: 'mem-007',
    incidentTitle: 'Notification Worker Kafka consumer lag escalation',
    service: 'notification-worker',
    severity: 'SEV-2',
    environment: 'Production',
    symptoms: [
      'Consumer lag exceeded 450,000 messages',
      'Push notification dispatch delayed by 40 minutes',
      'Worker pod CPU idle but processing stopped'
    ],
    rootCause: 'Malformed Unicode payload in message offset 849204 caused uncaught JSON parse exception, repeatedly failing and re-fetching the same offset in an infinite loop.',
    rootCauseCategory: 'Infrastructure',
    resolution: 'Deployed DLQ filter to skip corrupted offset and committed partition offset past the poison pill.',
    runbook: 'Kafka Consumer Lag & Poison Pill Mitigation',
    runbookCommands: [
      'kafka-consumer-groups.sh --bootstrap-server kafka:9092 --group notification-workers --reset-offsets --to-offset 849205 --execute --topic notifications',
      'kubectl rollout restart deployment/notification-worker -n production'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 15,
    engineerFeedback: 'Lag drained in under 4 minutes once the poison pill was bypassed into Dead Letter Queue.',
    createdAt: '2026-03-29T21:10:00Z'
  },
  {
    id: 'mem-008',
    incidentTitle: 'User API PostgreSQL replication lag & read freeze',
    service: 'user-api',
    severity: 'SEV-2',
    environment: 'Production',
    symptoms: [
      'Read-replica lag > 600 seconds',
      'Stale profile reads returned to end-users',
      'Vacuum freeze conflict on primary'
    ],
    rootCause: 'An orphaned transaction on the read-replica blocked WAL replay due to max_standby_streaming_delay timeout conflicts.',
    rootCauseCategory: 'Database',
    resolution: 'Terminated blocking backend on replica and increased standby streaming delay temporarily.',
    runbook: 'DB Connection Pool Recovery',
    runbookCommands: [
      "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE backend_type = 'client backend' AND state = 'idle in transaction';"
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 18,
    engineerFeedback: 'WAL replay resumed immediately and replica caught up within 90 seconds.',
    createdAt: '2026-02-14T04:25:00Z'
  },
  {
    id: 'mem-009',
    incidentTitle: 'Inventory Service root disk space exhaustion',
    service: 'inventory-service',
    severity: 'SEV-2',
    environment: 'Production',
    symptoms: [
      'No space left on device error (ENOSPC)',
      'Pods failing health checks with DiskPressure node condition',
      'Inventory update writes rejected'
    ],
    rootCause: 'Debug logging remained enabled after temporary troubleshooting session, filling /var/log/audit without logrotate rotation policy.',
    rootCauseCategory: 'Infrastructure',
    resolution: 'Purged rotated audit logs > 24 hours old, re-applied logrotate compression policy, and switched log level back to INFO.',
    runbook: 'DB Connection Pool Recovery',
    runbookCommands: [
      'find /var/log/audit -type f -name "*.log" -mtime +1 -delete',
      'kubectl set env deployment/inventory-service LOG_LEVEL=INFO -n production'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 8,
    engineerFeedback: 'Freed 45GB instantly. Added Prometheus alert for disk usage > 80%.',
    createdAt: '2026-01-19T13:15:00Z'
  },
  {
    id: 'mem-010',
    incidentTitle: 'API Gateway Nginx upstream connection refused',
    service: 'api-gateway',
    severity: 'SEV-1',
    environment: 'Production',
    symptoms: [
      '502 Bad Gateway across all public REST routes',
      'Upstream connect failed: connection refused to 10.244.x.x',
      'Kubernetes node maintenance drain in progress'
    ],
    rootCause: 'API Gateway Nginx resolver cached internal pod IPs for 300 seconds; node drain evicted pods but Nginx continued routing to dead IP addresses.',
    rootCauseCategory: 'Network',
    resolution: 'Reloaded Nginx configuration to flush DNS resolver cache and lowered resolver valid TTL to 5 seconds.',
    runbook: 'DB Connection Pool Recovery',
    runbookCommands: [
      'kubectl exec -it deployment/api-gateway -n production -- nginx -s reload'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 5,
    engineerFeedback: 'Nginx reload immediately discovered new pod IPs in the healthy node pool.',
    createdAt: '2026-01-05T09:40:00Z'
  },
  {
    id: 'mem-011',
    incidentTitle: 'Search Service Elasticsearch heap saturation & GC pauses',
    service: 'search-service',
    severity: 'SEV-2',
    environment: 'Production',
    symptoms: [
      'Stop-the-world JVM GC pauses exceeding 18 seconds',
      'Search cluster node disconnects and cluster health RED',
      'Search query timeouts on mobile app'
    ],
    rootCause: 'Unbounded wildcard regex query without fielddata limits consumed 98% of JVM old gen heap memory.',
    rootCauseCategory: 'Infrastructure',
    resolution: 'Cancelled active task query via ES tasks API and deployed search query sanitizer with strict wildcard restrictions.',
    runbook: 'DB Connection Pool Recovery',
    runbookCommands: [
      'curl -X POST "http://elasticsearch:9200/_tasks/_cancel?actions=*search*"',
      'curl -X POST "http://elasticsearch:9200/_cache/clear"'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 13,
    engineerFeedback: 'Cancelling running task cleared heap within seconds; ES cluster returned to GREEN.',
    createdAt: '2025-12-11T17:00:00Z'
  },
  {
    id: 'mem-012',
    incidentTitle: 'Billing Worker deadlocks on concurrent subscription renewals',
    service: 'billing-worker',
    severity: 'SEV-2',
    environment: 'Production',
    symptoms: [
      'PostgreSQL ERROR: deadlock detected',
      'Process 4819 waiting for ShareLock on transaction 92144',
      'Nightly billing batch processing failure'
    ],
    rootCause: 'Concurrent worker threads updated accounts and invoices in opposite table sequence, creating reciprocal lock dependencies.',
    rootCauseCategory: 'Database',
    resolution: 'Sorted account ID processing order monotonically to enforce deterministic lock ordering and retried failed batch transactions.',
    runbook: 'DB Connection Pool Recovery',
    runbookCommands: [
      'kubectl rollout restart deployment/billing-worker -n production'
    ],
    resolutionSuccessful: true,
    timeToResolutionMinutes: 20,
    engineerFeedback: 'Deterministic sorting eliminated lock cycle. Zero deadlocks during retry run.',
    createdAt: '2025-11-20T03:15:00Z'
  }
];

export const INITIAL_ACTIVE_INCIDENTS: Incident[] = [
  {
    id: 'inc-demo-primary',
    title: 'Payment API returning 500 errors',
    severity: 'SEV-1',
    service: 'payment-api',
    environment: 'Production',
    alertSource: 'Datadog',
    description: 'Payment API is returning HTTP 500 errors for all checkout transactions. Customer complaints spiking on Twitter and PagerDuty alert triggered. Latency has degraded from 120ms to > 10,000ms.',
    logs: `[ERROR] 2026-09-28 14:32:11
service=payment-api
status=500
message="Database connection pool exhausted"
active_connections=100
max_connections=100

ERROR sqlalchemy.exc.TimeoutError:
QueuePool limit of size 100 overflow 0 reached,
connection timed out.

payment-api response latency > 10 seconds`,
    status: 'action_required',
    createdAt: '2026-09-28T14:32:11Z',
    errorType: 'sqlalchemy.exc.TimeoutError: QueuePool limit reached',
    detectedSymptoms: [
      'HTTP 500 Internal Server Error spike',
      'Database connection pool exhausted (100/100 active)',
      'QueuePool acquire timeout error',
      'Latency degradation > 10 seconds'
    ],
    probableRootCause: {
      description: 'A database connection leak in payment-api is causing the connection pool to become exhausted, blocking all inbound checkout transactions.',
      confidence: 0.94,
      observedEvidence: [
        'Current pool utilization: 100/100 connections active',
        'Explicit sqlalchemy.exc.TimeoutError in logs',
        'Response latency > 10 seconds confirming connection queue starvation'
      ],
      historicalEvidence: [
        'Matches 3 historical payment-api incidents (mem-001, mem-003, mem-002)',
        'mem-001 had exact same QueuePool size 100 error caused by deployment v2.4.1 leak',
        'Rollback deployment had 100% resolution success rate within 7 minutes'
      ],
      hypothesis: 'A newly deployed code path or unhandled failure exception is omitting session closure, rapidly consuming all 100 pool connections.'
    },
    reasoningContext: 'The current incident closely matches 3 previous payment-api incidents involving database connection pool exhaustion. In historical incident mem-001, an identical QueuePool size 100 exhaustion occurred due to unclosed sessions. Rolling back to the prior stable deployment v2.4.0 and executing a rolling restart restored 100% of traffic in 7 minutes.',
    remediationStages: [
      {
        stageNumber: 1,
        stageName: 'Stage 1 — Immediate Workaround',
        steps: [
          {
            id: 'step-1-1',
            description: 'Check current database connection utilization and pod connection counts.',
            command: 'kubectl exec -it deployment/payment-api -n production -- python -c "from app import db; print(db.engine.pool.status())"',
            completed: true,
            riskLevel: 'safe'
          },
          {
            id: 'step-1-2',
            description: 'Identify recent deployment revision and whether connection leak correlates with latest rollout.',
            command: 'kubectl rollout history deployment/payment-api -n production',
            completed: true,
            riskLevel: 'safe'
          },
          {
            id: 'step-1-3',
            description: 'If customer impact is continuing, rollback payment-api to the previous stable deployment.',
            command: 'kubectl rollout undo deployment/payment-api -n production',
            completed: false,
            riskLevel: 'caution'
          },
          {
            id: 'step-1-4',
            description: 'Perform rolling restart of affected payment-api pods to terminate orphaned DB sessions.',
            command: 'kubectl rollout restart deployment/payment-api -n production',
            completed: false,
            riskLevel: 'caution'
          },
          {
            id: 'step-1-5',
            description: 'Monitor error rate and database connection count until baseline is restored.',
            command: 'kubectl get pods -n production -l app=payment-api -w',
            completed: false,
            riskLevel: 'safe'
          }
        ]
      },
      {
        stageNumber: 2,
        stageName: 'Stage 2 — Diagnostic Isolation',
        steps: [
          {
            id: 'step-2-1',
            description: 'Query PostgreSQL pg_stat_activity for lingering idle-in-transaction connections.',
            command: "psql $DATABASE_URL -c \"SELECT pid, state, query_start, query FROM pg_stat_activity WHERE state != 'idle';\"",
            completed: false,
            riskLevel: 'safe'
          },
          {
            id: 'step-2-2',
            description: 'Review git commit diff between current rollout and previous revision for unclosed db.session or missing try/finally blocks.',
            completed: false,
            riskLevel: 'safe'
          }
        ]
      },
      {
        stageNumber: 3,
        stageName: 'Stage 3 — Permanent Resolution',
        steps: [
          {
            id: 'step-3-1',
            description: 'Apply scoped session context manager patch in application repository.',
            completed: false,
            riskLevel: 'safe'
          },
          {
            id: 'step-3-2',
            description: 'Run integration test suite with connection leak assertion checks enabled.',
            completed: false,
            riskLevel: 'safe'
          }
        ]
      },
      {
        stageNumber: 4,
        stageName: 'Stage 4 — Post-Recovery Verification',
        steps: [
          {
            id: 'step-4-1',
            description: 'Verify 0 HTTP 500 responses across last 50,000 requests.',
            completed: false,
            riskLevel: 'safe'
          },
          {
            id: 'step-4-2',
            description: 'Confirm database pool connection count stabilizes below 25/100.',
            completed: false,
            riskLevel: 'safe'
          }
        ]
      }
    ],
    recommendedRunbook: INITIAL_RUNBOOKS[0],
    timeline: [
      {
        id: 'tl-1',
        timestamp: '2026-09-28T14:32:11Z',
        timeDisplay: '14:32',
        title: 'Incident Detected',
        description: 'PagerDuty alert triggered: HTTP 500 error spike & latency > 10s on payment-api.',
        type: 'detection'
      },
      {
        id: 'tl-2',
        timestamp: '2026-09-28T14:33:02Z',
        timeDisplay: '14:33',
        title: 'AI Analysis Started',
        description: 'Agent parsed stack trace, normalized error telemetry, and queried vector memory.',
        type: 'analysis'
      },
      {
        id: 'tl-3',
        timestamp: '2026-09-28T14:33:18Z',
        timeDisplay: '14:33',
        title: 'Historical Incidents Retrieved',
        description: 'Retrieved 3 highly relevant historical precedents from memory store (mem-001: 94% similarity).',
        type: 'memory'
      },
      {
        id: 'tl-4',
        timestamp: '2026-09-28T14:34:05Z',
        timeDisplay: '14:34',
        title: 'Remediation Plan Generated',
        description: 'Multi-stage mitigation plan and DB Connection Pool Recovery runbook recommended.',
        type: 'recommendation'
      }
    ],
    similarIncidents: [
      {
        id: 'sim-1',
        memoryId: 'mem-001',
        title: 'Payment API database connection pool exhaustion',
        service: 'payment-api',
        severity: 'SEV-1',
        rootCause: 'Connection leak introduced in deployment v2.4.1 where transaction contexts failed to close sessions.',
        resolution: 'Rollback deployment to v2.4.0 and restart affected pods.',
        similarityScore: 0.94,
        resolutionSuccessful: true,
        timeToResolutionMinutes: 7,
        date: '2026-08-14',
        runbookName: 'DB Connection Pool Recovery'
      },
      {
        id: 'sim-2',
        memoryId: 'mem-003',
        title: 'Payment API latency after deployment',
        service: 'payment-api',
        severity: 'SEV-1',
        rootCause: 'New code path failed to close database sessions in async callback.',
        resolution: 'Rollback deployment and patch connection lifecycle handling.',
        similarityScore: 0.88,
        resolutionSuccessful: true,
        timeToResolutionMinutes: 9,
        date: '2026-06-03',
        runbookName: 'DB Connection Pool Recovery'
      },
      {
        id: 'sim-3',
        memoryId: 'mem-002',
        title: 'Order Service database saturation',
        service: 'order-service',
        severity: 'SEV-2',
        rootCause: 'Long-running transactions caused connection starvation across pool.',
        resolution: 'Terminate long-running queries and increase pool timeout.',
        similarityScore: 0.81,
        resolutionSuccessful: true,
        timeToResolutionMinutes: 12,
        date: '2026-07-22',
        runbookName: 'DB Connection Pool Recovery'
      }
    ]
  }
];

export const DEMO_PRESETS = [
  {
    id: 'demo-payment-pool',
    label: 'Demo 1: Payment API Database Connection Pool Exhaustion (SEV-1)',
    title: 'Payment API returning 500 errors',
    severity: 'SEV-1' as const,
    service: 'payment-api',
    environment: 'Production' as const,
    alertSource: 'Datadog' as const,
    description: 'Payment API is returning HTTP 500 errors for all checkout transactions. Customer complaints spiking on Twitter and PagerDuty alert triggered. Latency has degraded from 120ms to > 10,000ms.',
    logs: `[ERROR] 2026-09-28 14:32:11
service=payment-api
status=500
message="Database connection pool exhausted"
active_connections=100
max_connections=100

ERROR sqlalchemy.exc.TimeoutError:
QueuePool limit of size 100 overflow 0 reached,
connection timed out.

payment-api response latency > 10 seconds`
  },
  {
    id: 'demo-k8s-crashloop',
    label: 'Demo 2: Kubernetes Payment Service CrashLoopBackOff (SEV-1)',
    title: 'Payment Service Worker Pods in CrashLoopBackOff',
    severity: 'SEV-1' as const,
    service: 'payment-service',
    environment: 'Production' as const,
    alertSource: 'PagerDuty' as const,
    description: 'Kubernetes monitoring reports 4 out of 4 replicas of payment-service crashing repeatedly with exit code 137. Transaction queue backlog increasing rapidly.',
    logs: `2026-09-28T14:40:02.194Z [WARN] Container payment-service-worker terminated with exit code 137 (OOMKilled)
Kubelet Event: Pod payment-service-worker-7df94b8cd5-x9q21 failed liveness probe
Back-off restarting failed container payment-service-worker in pod payment-service-worker-7df94b8cd5-x9q21_production
Java HotSpot(TM) 64-Bit Server VM warning: INFO: os::commit_memory(0x0000000780000000, 2147483648, 0) failed; error='Cannot allocate memory' (errno=12)
Memory cgroup out of memory: Killed process 1 (java) total-vm:4194304kB, anon-rss:2097152kB`
  },
  {
    id: 'demo-redis-timeout',
    label: 'Demo 3: Redis Connection Timeout Spike in Auth Service (SEV-2)',
    title: 'Auth Service Token Validation Timeouts & Redis Saturation',
    severity: 'SEV-2' as const,
    service: 'auth-service',
    environment: 'Production' as const,
    alertSource: 'Prometheus' as const,
    description: 'End users unable to refresh session tokens. Auth service response time spiked above 5,000ms. Redis client pool exhausted across all auth-service pods.',
    logs: `[ERROR] 2026-09-28 14:45:33 auth-service [http-nio-8080-exec-12]
org.springframework.data.redis.RedisConnectionFailureException: Cannot get Jedis connection; nested exception is redis.clients.jedis.exceptions.JedisConnectionException: Could not get a resource from the pool
Caused by: java.util.NoSuchElementException: Timeout waiting for idle object
    at org.apache.commons.pool2.impl.GenericObjectPool.borrowObject(GenericObjectPool.java:449)
    at redis.clients.jedis.util.Pool.getResource(Pool.java:50)
Active Redis Clients: 500 / 500. Redis Server Latency: 4200ms`
  }
];
