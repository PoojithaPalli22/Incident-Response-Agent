export type Severity = 'SEV-1' | 'SEV-2' | 'SEV-3' | 'SEV-4';
export type Environment = 'Production' | 'Staging' | 'Development';
export type AlertSource = 'PagerDuty' | 'Datadog' | 'Prometheus' | 'CloudWatch' | 'Manual' | 'Other';
export type IncidentStatus = 'detected' | 'analyzing' | 'action_required' | 'mitigating' | 'resolved';

export interface RemediationStep {
  id: string;
  description: string;
  command?: string;
  completed: boolean;
  riskLevel: 'safe' | 'caution' | 'critical';
}

export interface RemediationStage {
  stageNumber: number;
  stageName: string;
  steps: RemediationStep[];
}

export interface RecommendedRunbook {
  id: string;
  name: string;
  description: string;
  targetService: string;
  successRate: number;
  steps: string[];
  commands: string[];
  warning: string;
}

export interface TimelineEvent {
  id: string;
  timestamp: string;
  timeDisplay: string;
  title: string;
  description: string;
  type: 'detection' | 'analysis' | 'memory' | 'recommendation' | 'simulation' | 'mitigation' | 'resolved';
}

export interface SimulationLog {
  command: string;
  outputLines: string[];
  status: 'running' | 'success' | 'failed';
  delayMs?: number;
}

export interface PostMortem {
  actualFix: string;
  utilityRating: 'Very useful' | 'Useful' | 'Partially useful' | 'Not useful';
  actualRootCause: string;
  agentMemoryTakeaway: string;
  resolvedAt: string;
  timeToResolutionMinutes: number;
  resolutionSuccessful: boolean;
}

export interface IncidentMemory {
  id: string;
  incidentId?: string;
  incidentTitle: string;
  service: string;
  severity: Severity;
  environment?: Environment;
  symptoms: string[];
  rootCause: string;
  rootCauseCategory: 'Database' | 'Kubernetes' | 'Application' | 'Infrastructure' | 'Network' | 'Security';
  resolution: string;
  runbook: string;
  runbookCommands?: string[];
  resolutionSuccessful: boolean;
  timeToResolutionMinutes: number;
  engineerFeedback: string;
  createdAt: string;
  embedding?: number[];
  isLiveLearned?: boolean;
}

export interface SimilarIncident {
  id: string;
  memoryId: string;
  title: string;
  service: string;
  severity: Severity;
  rootCause: string;
  resolution: string;
  similarityScore: number; // 0.0 - 1.0 (e.g. 0.94)
  resolutionSuccessful: boolean;
  timeToResolutionMinutes: number;
  date: string;
  runbookName: string;
  isLiveLearned?: boolean;
}

export interface ProbableRootCause {
  description: string;
  confidence: number; // 0.0 - 1.0
  observedEvidence: string[];
  historicalEvidence: string[];
  hypothesis: string;
}

export interface Incident {
  id: string;
  title: string;
  severity: Severity;
  service: string;
  environment: Environment;
  description: string;
  logs: string;
  alertSource: AlertSource;
  status: IncidentStatus;
  createdAt: string;
  resolvedAt?: string;
  errorType?: string;
  detectedSymptoms: string[];
  probableRootCause?: ProbableRootCause;
  similarIncidents?: SimilarIncident[];
  reasoningContext?: string;
  remediationStages?: RemediationStage[];
  recommendedRunbook?: RecommendedRunbook;
  timeline: TimelineEvent[];
  simulationResults?: SimulationLog[];
  postMortem?: PostMortem;
  isLiveCreated?: boolean;
}

export interface AgentActivityStep {
  id: string;
  label: string;
  detail: string;
  status: 'pending' | 'active' | 'completed' | 'failed';
  durationMs?: number;
}
