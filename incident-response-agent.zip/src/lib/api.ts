import { Incident, IncidentMemory, RecommendedRunbook, SimilarIncident } from '../types/incident';

export interface DashboardMetrics {
  totalIncidents: number;
  activeIncidents: number;
  resolvedIncidents: number;
  averageResolutionTime: string;
  historicalMemories: number;
  successfulRunbooks: number;
  aiAssistedResolutionRate: string;
  vectorIndexType: string;
  activeModel: string;
}

export const api = {
  async getMetrics(): Promise<DashboardMetrics> {
    const res = await fetch('/api/metrics');
    if (!res.ok) throw new Error('Failed to fetch metrics');
    return res.json();
  },

  async getIncidents(): Promise<Incident[]> {
    const res = await fetch('/api/incidents');
    if (!res.ok) throw new Error('Failed to fetch incidents');
    return res.json();
  },

  async getIncident(id: string): Promise<Incident> {
    const res = await fetch(`/api/incidents/${id}`);
    if (!res.ok) throw new Error('Failed to fetch incident');
    return res.json();
  },

  async createIncident(data: Partial<Incident>): Promise<Incident> {
    const res = await fetch('/api/incidents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to create incident');
    return res.json();
  },

  async analyzeIncident(id: string): Promise<{ incident: Incident; activitySteps: any[]; providerUsed: string }> {
    const res = await fetch(`/api/incidents/${id}/analyze`, {
      method: 'POST'
    });
    if (!res.ok) throw new Error('Failed to analyze incident');
    return res.json();
  },

  async getSimilarIncidents(id: string): Promise<SimilarIncident[]> {
    const res = await fetch(`/api/incidents/${id}/similar`);
    if (!res.ok) throw new Error('Failed to fetch similar incidents');
    return res.json();
  },

  async toggleStep(incidentId: string, stepId: string, completed?: boolean): Promise<Incident> {
    const res = await fetch(`/api/incidents/${incidentId}/step`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stepId, completed })
    });
    if (!res.ok) throw new Error('Failed to update step');
    return res.json();
  },

  async simulateRunbook(incidentId: string): Promise<{ incident: Incident; simulationLogs: any[] }> {
    const res = await fetch(`/api/incidents/${incidentId}/simulate`, {
      method: 'POST'
    });
    if (!res.ok) throw new Error('Failed to simulate runbook');
    return res.json();
  },

  async resolveIncident(
    id: string,
    data: {
      actualFix: string;
      utilityRating: string;
      actualRootCause: string;
      agentMemoryTakeaway: string;
      resolutionTimeMinutes: number;
    }
  ): Promise<{ incident: Incident; createdMemory: IncidentMemory; message: string }> {
    const res = await fetch(`/api/incidents/${id}/resolve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to resolve incident');
    return res.json();
  },

  async getMemories(params?: {
    query?: string;
    service?: string;
    severity?: string;
    category?: string;
    successOnly?: boolean;
  }): Promise<IncidentMemory[]> {
    const searchParams = new URLSearchParams();
    if (params?.query) searchParams.set('query', params.query);
    if (params?.service) searchParams.set('service', params.service);
    if (params?.severity) searchParams.set('severity', params.severity);
    if (params?.category) searchParams.set('category', params.category);
    if (params?.successOnly) searchParams.set('successOnly', 'true');

    const res = await fetch(`/api/memory?${searchParams.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch memories');
    return res.json();
  },

  async getMemory(id: string): Promise<IncidentMemory> {
    const res = await fetch(`/api/memory/${id}`);
    if (!res.ok) throw new Error('Failed to fetch memory');
    return res.json();
  },

  async getRunbooks(): Promise<RecommendedRunbook[]> {
    const res = await fetch('/api/runbooks');
    if (!res.ok) throw new Error('Failed to fetch runbooks');
    return res.json();
  },

  async resetData(): Promise<void> {
    const res = await fetch('/api/reset', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to reset data');
  }
};
