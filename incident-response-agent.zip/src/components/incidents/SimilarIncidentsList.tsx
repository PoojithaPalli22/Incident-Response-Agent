import React from 'react';
import { SimilarIncident } from '../../types/incident';
import { SimilarityBar } from '../common/SimilarityBar';
import { Database, CheckCircle2, Clock, Wrench, Sparkles, ExternalLink } from 'lucide-react';

interface SimilarIncidentsListProps {
  incidents: SimilarIncident[];
  onOpenPostMortem?: (incident: SimilarIncident) => void;
}

export const SimilarIncidentsList: React.FC<SimilarIncidentsListProps> = ({
  incidents,
  onOpenPostMortem
}) => {
  if (!incidents || incidents.length === 0) {
    return (
      <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-6 text-center text-slate-400 font-mono text-xs">
        No similar historical incidents found in vector memory.
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-5 shadow-lg space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center">
            <Database className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-sm font-sans tracking-wide">
              Similar Incidents From Memory
            </h3>
            <p className="text-xs text-slate-400">
              Retrieved from 384-dimensional vector database using cosine semantic similarity
            </p>
          </div>
        </div>

        <div className="text-xs font-mono text-slate-400">
          Top {incidents.length} Vector Precedents
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {incidents.map((incident, idx) => (
          <div
            key={incident.id || idx}
            className={`rounded-xl border p-4 flex flex-col justify-between transition-all bg-[#090e19]/90 hover:border-cyan-500/40 ${
              incident.isLiveLearned
                ? 'border-emerald-500/40 ring-1 ring-emerald-500/20'
                : 'border-slate-800 hover:bg-[#0c1220]'
            }`}
          >
            <div className="space-y-3">
              {/* Header with similarity bar and badge */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800/80 text-slate-300 border border-slate-700">
                    {incident.service}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    {incident.date}
                  </span>
                </div>

                <h4 className="font-semibold text-sm text-slate-100 leading-snug line-clamp-2 font-sans">
                  {incident.title}
                </h4>

                {incident.isLiveLearned && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-400 border border-emerald-600/40">
                    <Sparkles className="w-3 h-3 text-emerald-400 animate-pulse" />
                    Learned from Live Incident
                  </span>
                )}

                {/* Similarity meter */}
                <SimilarityBar score={incident.similarityScore} />
              </div>

              {/* Root cause and resolution */}
              <div className="space-y-2 pt-2 border-t border-slate-800/80 text-xs font-sans">
                <div>
                  <span className="text-[11px] font-mono uppercase text-slate-400 font-semibold block mb-0.5">
                    Root Cause:
                  </span>
                  <p className="text-slate-300 text-xs leading-relaxed line-clamp-2">
                    {incident.rootCause}
                  </p>
                </div>

                <div>
                  <span className="text-[11px] font-mono uppercase text-cyan-400 font-semibold block mb-0.5">
                    Resolution:
                  </span>
                  <p className="text-slate-300 text-xs leading-relaxed line-clamp-2">
                    {incident.resolution}
                  </p>
                </div>
              </div>
            </div>

            {/* Footer metrics */}
            <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-slate-300">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  {incident.timeToResolutionMinutes}m
                </span>
                <span className="flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Success
                </span>
              </div>

              {onOpenPostMortem && (
                <button
                  onClick={() => onOpenPostMortem(incident)}
                  className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-mono text-[11px] hover:underline"
                >
                  <span>Post-Mortem</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
