import React, { useState, useEffect } from 'react';
import { Terminal, X, Play, CheckCircle2, RotateCcw, ShieldCheck, AlertCircle } from 'lucide-react';

interface SimulationModalProps {
  isOpen: boolean;
  onClose: () => void;
  service: string;
  runbookName: string;
  commands: string[];
  onSimulationCompleted: () => void;
}

interface TerminalStep {
  command: string;
  outputs: string[];
  delayMs: number;
}

export const SimulationModal: React.FC<SimulationModalProps> = ({
  isOpen,
  onClose,
  service,
  runbookName,
  commands,
  onSimulationCompleted
}) => {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(-1);
  const [printedLines, setPrintedLines] = useState<string[]>([]);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const simulationSteps: TerminalStep[] = [
    {
      command: `kubectl rollout history deployment/${service} -n production`,
      outputs: [
        `deployment.apps/${service}`,
        `REVISION  CHANGE-CAUSE`,
        `40        v2.4.0 (stable production release)`,
        `41        v2.4.1 (feature: async transaction telemetry logger)`,
        `✓ History inspected: revision 40 identified as previous stable state.`
      ],
      delayMs: 800
    },
    {
      command: `kubectl rollout undo deployment/${service} -n production`,
      outputs: [
        `Initiating deployment rollback...`,
        `deployment.apps/${service} rollback to revision 40 initiated.`,
        `Scheduling pod eviction for pods running v2.4.1...`
      ],
      delayMs: 1100
    },
    {
      command: `kubectl rollout status deployment/${service} -n production --timeout=90s`,
      outputs: [
        `Waiting for deployment "${service}" rollout to finish: 1 out of 3 new replicas updated...`,
        `Waiting for deployment "${service}" rollout to finish: 2 out of 3 new replicas updated...`,
        `Waiting for deployment "${service}" rollout to finish: 3 out of 3 new replicas updated...`,
        `✓ deployment.apps/${service} successfully rolled out (v2.4.0 active).`
      ],
      delayMs: 1400
    },
    {
      command: `kubectl get pods -n production -l app=${service} -o wide`,
      outputs: [
        `NAME                            READY   STATUS    RESTARTS   AGE   IP`,
        `${service}-7b8c8d8b6-x4m21     1/1     Running   0          22s   10.244.2.14`,
        `${service}-7b8c8d8b6-9zq10     1/1     Running   0          19s   10.244.3.88`,
        `${service}-7b8c8d8b6-lp33a     1/1     Running   0          16s   10.244.1.62`,
        ``,
        `[SIMULATION TELEMETRY VERIFICATION]`,
        `✓ Active DB Connection Pool: 100/100 -> 24/100 (HEALTHY)`,
        `✓ HTTP 500 Error Rate: 48.2% -> 0.02% (NORMALIZED)`,
        `✓ P99 Response Latency: 10,240ms -> 118ms (BASELINE RESTORED)`,
        `✓ Simulated remediation completed successfully.`
      ],
      delayMs: 1300
    }
  ];

  const runSimulation = () => {
    setIsRunning(true);
    setIsFinished(false);
    setPrintedLines([
      `# Initializing safe SRE simulation sandbox for ${service}...`,
      `# Target runbook: "${runbookName}"`,
      `# Sandbox status: ISOLATED (Zero direct infrastructure mutation)`,
      ``
    ]);
    setCurrentStepIndex(0);
  };

  useEffect(() => {
    if (!isRunning || currentStepIndex < 0) return;

    if (currentStepIndex >= simulationSteps.length) {
      setIsRunning(false);
      setIsFinished(true);
      onSimulationCompleted();
      return;
    }

    const step = simulationSteps[currentStepIndex];
    // Print command immediately
    setPrintedLines(prev => [...prev, `$ ${step.command}`]);

    // Delay then print outputs
    const timer = setTimeout(() => {
      setPrintedLines(prev => [...prev, ...step.outputs, '']);
      setCurrentStepIndex(prev => prev + 1);
    }, step.delayMs);

    return () => clearTimeout(timer);
  }, [isRunning, currentStepIndex]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-3xl rounded-xl border border-slate-700 bg-[#070b12] shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Terminal Title Bar */}
        <div className="px-4 py-3 bg-[#0d1322] border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
            </div>
            <span className="text-xs font-mono font-semibold text-slate-300 ml-2">
              SRE Terminal Simulator — {service}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/40">
              Demo Sandbox Mode
            </span>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Warning banner inside terminal */}
        <div className="bg-amber-950/30 border-b border-amber-900/40 px-4 py-2 text-xs font-mono text-amber-300/90 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Simulation Mode: Demonstrating automated runbook execution with realistic telemetry feedback.</span>
        </div>

        {/* Terminal Screen */}
        <div className="flex-1 p-4 overflow-y-auto font-mono text-xs text-slate-300 bg-[#06090f] space-y-1 select-text">
          {printedLines.map((line, idx) => {
            if (line.startsWith('$ ')) {
              return (
                <div key={idx} className="text-cyan-300 font-bold flex items-center gap-1.5 pt-1">
                  <span>{line}</span>
                </div>
              );
            }
            if (line.startsWith('✓ ')) {
              return (
                <div key={idx} className="text-emerald-400 font-medium">
                  {line}
                </div>
              );
            }
            if (line.startsWith('# ')) {
              return (
                <div key={idx} className="text-slate-400">
                  {line}
                </div>
              );
            }
            return (
              <div key={idx} className="text-slate-300">
                {line}
              </div>
            );
          })}

          {isRunning && (
            <div className="inline-block w-2 h-4 bg-cyan-400 animate-pulse ml-1 align-middle" />
          )}

          {!isRunning && printedLines.length === 0 && (
            <div className="text-slate-400 py-8 text-center space-y-2">
              <Terminal className="w-8 h-8 text-slate-400 mx-auto" />
              <p>Ready to simulate runbook: <strong className="text-slate-300">{runbookName}</strong></p>
              <p className="text-[11px] text-slate-400">Click &quot;Start Simulation&quot; below to execute simulated rollback & recovery.</p>
            </div>
          )}
        </div>

        {/* Terminal Controls */}
        <div className="p-3 bg-[#0d1322] border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isFinished ? (
              <span className="flex items-center gap-1.5 text-xs font-mono text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                Remediation verified! Impact mitigated.
              </span>
            ) : isRunning ? (
              <span className="flex items-center gap-1.5 text-xs font-mono text-cyan-400 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-cyan-400" />
                Executing rollback simulation...
              </span>
            ) : (
              <span className="text-xs font-mono text-slate-400">
                Commands mapped from historical resolution runbook
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {!isRunning && !isFinished && (
              <button
                onClick={runSimulation}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-semibold shadow-lg shadow-cyan-950 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Start Simulation</span>
              </button>
            )}

            {isFinished && (
              <button
                onClick={runSimulation}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-slate-600 text-xs font-mono text-slate-300"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Rerun</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-700 hover:border-slate-600 bg-slate-800/80 hover:bg-slate-800 text-xs font-mono text-slate-200"
            >
              {isFinished ? 'Done' : 'Cancel'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
