import React, { useState } from 'react';
import { Incident, Severity } from '../../types/incident';
import { SeverityBadge } from '../common/SeverityBadge';
import { StatusBadge } from '../common/StatusBadge';
import { AlertTriangle, Clock, ArrowRight, PlusCircle, Search, Filter } from 'lucide-react';

interface IncidentListViewProps {
  incidents: Incident[];
  onSelectIncident: (incident: Incident) => void;
  onNewIncident: () => void;
}

export const IncidentListView: React.FC<IncidentListViewProps> = ({
  incidents,
  onSelectIncident,
  onNewIncident
}) => {
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filtered = incidents.filter(inc => {
    if (filterSeverity !== 'all' && inc.severity !== filterSeverity) return false;
    if (filterStatus !== 'all') {
      if (filterStatus === 'active' && inc.status === 'resolved') return false;
      if (filterStatus === 'resolved' && inc.status !== 'resolved') return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        inc.title.toLowerCase().includes(q) ||
        inc.service.toLowerCase().includes(q) ||
        (inc.description && inc.description.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="space-y-5 pb-12 animate-in fade-in duration-200">
      {/* Header and CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-100 font-sans tracking-tight">
            Production Incidents
          </h2>
          <p className="text-xs text-slate-400 font-sans">
            Active and resolved outages monitored by the Incident Response Agent
          </p>
        </div>

        <button
          onClick={onNewIncident}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-medium text-xs font-sans shadow-lg shadow-cyan-950/50 transition-all cursor-pointer self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>+ New Incident</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-3 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by title, service, or keyword..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-black/40 border border-slate-700/80 focus:border-cyan-500 text-xs font-mono text-slate-200 placeholder:text-slate-400 outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          {/* Severity filter */}
          <select
            value={filterSeverity}
            onChange={e => setFilterSeverity(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-black/40 border border-slate-700/80 text-xs font-mono text-slate-200 outline-none"
          >
            <option value="all">All Severities</option>
            <option value="SEV-1">SEV-1 Only</option>
            <option value="SEV-2">SEV-2 Only</option>
            <option value="SEV-3">SEV-3 Only</option>
            <option value="SEV-4">SEV-4 Only</option>
          </select>

          {/* Status filter */}
          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-black/40 border border-slate-700/80 text-xs font-mono text-slate-200 outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active Only</option>
            <option value="resolved">Resolved Only</option>
          </select>
        </div>
      </div>

      {/* Incidents Table / Cards */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-8 text-center text-slate-400 font-mono text-xs">
            No incidents match your selected filters.
          </div>
        ) : (
          filtered.map(inc => (
            <div
              key={inc.id}
              onClick={() => onSelectIncident(inc)}
              className="rounded-xl border border-slate-800 hover:border-cyan-500/40 bg-[#0d1322] hover:bg-[#0f172a] p-4 transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 group shadow-md"
            >
              <div className="space-y-2 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <SeverityBadge severity={inc.severity} size="sm" />
                  <StatusBadge status={inc.status} />
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {inc.service}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {inc.createdAt ? new Date(inc.createdAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : 'Recent'}
                  </span>
                </div>

                <h3 className="font-semibold text-sm text-slate-100 group-hover:text-cyan-300 font-sans transition-colors">
                  {inc.title}
                </h3>

                <p className="text-xs text-slate-400 line-clamp-1 font-sans">
                  {inc.description}
                </p>

                {inc.similarIncidents && inc.similarIncidents.length > 0 && (
                  <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400 pt-1">
                    <span className="text-cyan-400">
                      ✓ {inc.similarIncidents.length} historical memories matched
                    </span>
                    <span>•</span>
                    <span>
                      Top match: {Math.round((inc.similarIncidents[0]?.similarityScore || 0) * 100)}% similarity
                    </span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3 self-end md:self-center shrink-0">
                <button
                  type="button"
                  className="px-3.5 py-1.5 rounded-lg border border-slate-700 group-hover:border-cyan-500/40 bg-slate-800/80 group-hover:bg-cyan-950/40 text-xs font-mono text-slate-300 group-hover:text-cyan-300 flex items-center gap-1.5 transition-colors"
                >
                  <span>View Analysis</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
