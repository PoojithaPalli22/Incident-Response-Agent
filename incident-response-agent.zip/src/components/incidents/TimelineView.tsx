import React from 'react';
import { TimelineEvent } from '../../types/incident';
import { Clock, ShieldAlert, BrainCircuit, Database, CheckSquare, Play, Sparkles, CheckCircle2 } from 'lucide-react';

interface TimelineViewProps {
  events: TimelineEvent[];
}

export const TimelineView: React.FC<TimelineViewProps> = ({ events }) => {
  if (!events || events.length === 0) return null;

  const getIcon = (type: TimelineEvent['type']) => {
    switch (type) {
      case 'detection':
        return <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />;
      case 'analysis':
        return <BrainCircuit className="w-3.5 h-3.5 text-purple-400" />;
      case 'memory':
        return <Database className="w-3.5 h-3.5 text-cyan-400" />;
      case 'recommendation':
        return <CheckSquare className="w-3.5 h-3.5 text-amber-400" />;
      case 'simulation':
        return <Play className="w-3.5 h-3.5 text-indigo-400 fill-current" />;
      case 'mitigation':
        return <Sparkles className="w-3.5 h-3.5 text-cyan-400" />;
      case 'resolved':
        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <Clock className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const getDotBorder = (type: TimelineEvent['type']) => {
    switch (type) {
      case 'detection':
        return 'border-rose-500/50 bg-rose-950/80';
      case 'analysis':
        return 'border-purple-500/50 bg-purple-950/80';
      case 'memory':
        return 'border-cyan-500/50 bg-cyan-950/80';
      case 'recommendation':
        return 'border-amber-500/50 bg-amber-950/80';
      case 'simulation':
        return 'border-indigo-500/50 bg-indigo-950/80';
      case 'resolved':
        return 'border-emerald-500/50 bg-emerald-950/80';
      default:
        return 'border-slate-700 bg-slate-800';
    }
  };

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-5 shadow-lg space-y-4">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center">
          <Clock className="w-4 h-4 text-indigo-400" />
        </div>
        <div>
          <h3 className="font-semibold text-slate-100 text-sm font-sans tracking-wide">
            Incident Timeline
          </h3>
          <p className="text-xs text-slate-400">
            Chronological audit log of detection, retrieval, simulation, and resolution events
          </p>
        </div>
      </div>

      <div className="relative pl-6 space-y-4 before:content-[''] before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-800">
        {events.map((evt, idx) => (
          <div key={evt.id || idx} className="relative flex items-start gap-3 group">
            {/* Timeline node icon */}
            <div
              className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full border flex items-center justify-center shadow-md ${getDotBorder(
                evt.type
              )}`}
            >
              {getIcon(evt.type)}
            </div>

            <div className="flex-1 bg-slate-900/60 rounded-lg border border-slate-800/80 p-3 text-xs transition-colors hover:border-slate-700">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="font-semibold text-slate-200 font-sans">{evt.title}</span>
                <span className="font-mono text-[11px] text-cyan-400 shrink-0">
                  {evt.timeDisplay || evt.timestamp?.slice(11, 16)}
                </span>
              </div>
              <p className="text-slate-400 font-sans leading-relaxed text-[11px]">
                {evt.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
