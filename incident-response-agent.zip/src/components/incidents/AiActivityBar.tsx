import React from 'react';
import { AgentActivityStep } from '../../types/incident';
import { CheckCircle2, Clock, Sparkles } from 'lucide-react';

interface AiActivityBarProps {
  steps: AgentActivityStep[];
  isAnalyzing?: boolean;
}

export const AiActivityBar: React.FC<AiActivityBarProps> = ({ steps, isAnalyzing }) => {
  if (!steps || steps.length === 0) return null;

  return (
    <div className="rounded-xl border border-indigo-950/70 bg-[#0d1326]/70 p-4 backdrop-blur-sm">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <h4 className="text-xs font-mono font-semibold text-slate-200 uppercase tracking-wider">
            AI Agent Execution Trace & Observability
          </h4>
        </div>
        <span className="text-[11px] font-mono text-cyan-400/90 bg-cyan-950/40 border border-cyan-800/40 px-2.5 py-0.5 rounded-full">
          RAG Pipeline Complete
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {steps.map(step => (
          <div
            key={step.id}
            className="flex items-start gap-2.5 p-2.5 rounded-lg bg-slate-900/80 border border-slate-800/80 text-xs font-mono"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-200 truncate">{step.label}</span>
                {step.durationMs && (
                  <span className="text-[10px] text-slate-400 flex items-center gap-1 shrink-0">
                    <Clock className="w-2.5 h-2.5" />
                    {step.durationMs}ms
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{step.detail}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
