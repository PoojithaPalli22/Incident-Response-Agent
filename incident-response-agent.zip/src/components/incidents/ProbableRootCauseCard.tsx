import React from 'react';
import { ProbableRootCause } from '../../types/incident';
import { AlertCircle, Eye, History, Sparkles, CheckCircle2 } from 'lucide-react';

interface ProbableRootCauseCardProps {
  rootCause: ProbableRootCause;
}

export const ProbableRootCauseCard: React.FC<ProbableRootCauseCardProps> = ({ rootCause }) => {
  const confidencePercent = Math.round(rootCause.confidence * 100);

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-5 shadow-lg space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center">
            <AlertCircle className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-sm font-sans tracking-wide">
              Probable Root Cause Analysis
            </h3>
            <p className="text-xs text-slate-400">
              Grounded evidence synthesis separating observed telemetry from AI hypothesis
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Model Confidence:</span>
          <span className="px-2.5 py-0.5 rounded-full font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
            {confidencePercent}% High
          </span>
        </div>
      </div>

      {/* Main explanation */}
      <div className="p-3.5 rounded-lg bg-slate-900/90 border border-slate-800 text-sm font-sans text-slate-200 leading-relaxed">
        {rootCause.description}
      </div>

      {/* Tripartite Evidence Breakdown (Requirement 9) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
        {/* 1. Observed Evidence */}
        <div className="rounded-lg bg-slate-900/60 border border-slate-800/80 p-3.5 space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-cyan-300 uppercase tracking-wider">
            <Eye className="w-3.5 h-3.5" />
            <span>Observed Evidence</span>
          </div>
          <p className="text-[11px] text-slate-400">Facts detected directly in incoming logs & telemetry:</p>
          <ul className="space-y-1.5 text-xs text-slate-300 font-sans">
            {rootCause.observedEvidence.map((item, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-cyan-400 shrink-0 font-bold">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* 2. Historical Evidence */}
        <div className="rounded-lg bg-slate-900/60 border border-slate-800/80 p-3.5 space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-indigo-300 uppercase tracking-wider">
            <History className="w-3.5 h-3.5" />
            <span>Historical Evidence</span>
          </div>
          <p className="text-[11px] text-slate-400">Correlated patterns from prior verified post-mortems:</p>
          <ul className="space-y-1.5 text-xs text-slate-300 font-sans">
            {rootCause.historicalEvidence.map((item, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-indigo-400 shrink-0 font-bold">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* 3. AI Hypothesis */}
        <div className="rounded-lg bg-slate-900/60 border border-slate-800/80 p-3.5 space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-amber-300 uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Hypothesis</span>
          </div>
          <p className="text-[11px] text-slate-400">Working diagnosis requiring verification:</p>
          <p className="text-xs text-slate-300 font-sans leading-relaxed">
            {rootCause.hypothesis}
          </p>
          <div className="pt-2 text-[10px] font-mono text-slate-400 italic">
            * Hypothesis remains unverified until diagnostic commands are run.
          </div>
        </div>
      </div>
    </div>
  );
};
