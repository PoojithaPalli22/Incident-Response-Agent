import React, { useState } from 'react';
import { Severity, Environment, AlertSource } from '../../types/incident';
import { DEMO_PRESETS } from '../../server/seedData';
import {
  Sparkles,
  Terminal,
  ShieldAlert,
  Server,
  Layers,
  Send,
  Zap,
  CheckCircle2,
  Database,
  BrainCircuit
} from 'lucide-react';

interface NewIncidentViewProps {
  onSubmit: (incidentData: {
    title: string;
    severity: Severity;
    service: string;
    environment: Environment;
    description: string;
    logs: string;
    alertSource: AlertSource;
  }) => Promise<void>;
  isAnalyzing: boolean;
}

export const NewIncidentView: React.FC<NewIncidentViewProps> = ({ onSubmit, isAnalyzing }) => {
  const [title, setTitle] = useState('Payment API returning 500 errors');
  const [severity, setSeverity] = useState<Severity>('SEV-1');
  const [service, setService] = useState('payment-api');
  const [environment, setEnvironment] = useState<Environment>('Production');
  const [alertSource, setAlertSource] = useState<AlertSource>('Datadog');
  const [description, setDescription] = useState(
    'Payment API is returning HTTP 500 errors for all checkout transactions. Customer complaints spiking on Twitter and PagerDuty alert triggered. Latency has degraded from 120ms to > 10,000ms.'
  );
  const [logs, setLogs] = useState(`[ERROR] 2026-09-28 14:32:11
service=payment-api
status=500
message="Database connection pool exhausted"
active_connections=100
max_connections=100

ERROR sqlalchemy.exc.TimeoutError:
QueuePool limit of size 100 overflow 0 reached,
connection timed out.

payment-api response latency > 10 seconds`);

  // Active step animation during analysis
  const [currentStep, setCurrentStep] = useState(0);

  const applyDemoPreset = (preset: (typeof DEMO_PRESETS)[0]) => {
    setTitle(preset.title);
    setSeverity(preset.severity);
    setService(preset.service);
    setEnvironment(preset.environment);
    setAlertSource(preset.alertSource);
    setDescription(preset.description);
    setLogs(preset.logs);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !service) return;

    await onSubmit({
      title,
      severity,
      service,
      environment,
      description,
      logs,
      alertSource
    });
  };

  const loadingSteps = [
    'Analyzing incident telemetry & logs...',
    'Generating 384-dimensional vector embedding...',
    'Searching historical incident memory...',
    'Finding top similar incidents via cosine distance...',
    'Analyzing probable root cause with historical precedents...',
    'Generating 4-stage actionable remediation plan...'
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/40 uppercase font-semibold">
            Agent Ingestion Pipeline
          </span>
        </div>
        <h2 className="text-xl md:text-2xl font-bold text-slate-100 font-sans tracking-tight">
          Trigger Incident Analysis & Memory Retrieval
        </h2>
        <p className="text-xs text-slate-400 font-sans">
          Submit logs, stack traces, and alert context. The Incident Response Agent retrieves relevant organizational memories, isolates root cause, and generates targeted remediation runbooks.
        </p>
      </div>

      {/* Demo Mode Presets (Requirement 24) */}
      <div className="rounded-xl border border-indigo-900/60 bg-gradient-to-r from-[#0d1326] to-[#080d1a] p-4 space-y-2.5 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400 fill-current" />
            <span className="text-xs font-mono font-semibold text-slate-200 uppercase tracking-wider">
              Quick Demo Presets
            </span>
          </div>
          <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/50 border border-cyan-800/40 px-2 py-0.5 rounded">
            1-Click Demo Scenarios
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          {DEMO_PRESETS.map((preset, idx) => (
            <button
              type="button"
              key={preset.id}
              onClick={() => applyDemoPreset(preset)}
              className="p-2.5 rounded-lg border border-slate-800 hover:border-cyan-500/50 bg-slate-900/80 hover:bg-slate-900 text-left transition-all group cursor-pointer"
            >
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                <span className="text-cyan-400 font-semibold">Demo {idx + 1}</span>
                <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                  {preset.service}
                </span>
              </div>
              <div className="text-xs font-sans font-semibold text-slate-200 group-hover:text-cyan-300 line-clamp-1">
                {preset.title}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Submission Form */}
      <form onSubmit={handleSubmit} className="rounded-xl border border-slate-800 bg-[#0d1322] p-6 shadow-xl space-y-5">
        {/* Title */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-200 block font-sans">
            Incident Title <span className="text-rose-400">*</span>
          </label>
          <input
            type="text"
            required
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="e.g. Payment API returning 500 errors"
            className="w-full px-3.5 py-2.5 rounded-lg bg-black/50 border border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-100 text-sm font-sans outline-none"
          />
        </div>

        {/* Severity, Service, Environment, Alert Source */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Severity */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-200 block font-sans">
              Severity Level
            </label>
            <div className="grid grid-cols-4 gap-1">
              {(['SEV-1', 'SEV-2', 'SEV-3', 'SEV-4'] as const).map(sev => {
                const isSelected = severity === sev;
                const colors = {
                  'SEV-1': isSelected ? 'bg-rose-500/20 text-rose-300 border-rose-500/60 font-bold' : 'border-slate-800 text-slate-400 hover:text-slate-200',
                  'SEV-2': isSelected ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 font-bold' : 'border-slate-800 text-slate-400 hover:text-slate-200',
                  'SEV-3': isSelected ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/60 font-bold' : 'border-slate-800 text-slate-400 hover:text-slate-200',
                  'SEV-4': isSelected ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/60 font-bold' : 'border-slate-800 text-slate-400 hover:text-slate-200'
                };
                return (
                  <button
                    type="button"
                    key={sev}
                    onClick={() => setSeverity(sev)}
                    className={`py-1.5 text-xs font-mono rounded border transition-colors ${colors[sev]}`}
                  >
                    {sev}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Service */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-200 block font-sans">
              Target Service <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={service}
              onChange={e => setService(e.target.value)}
              placeholder="e.g. payment-api"
              className="w-full px-3 py-2 rounded-lg bg-black/50 border border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-100 text-xs font-mono outline-none"
            />
          </div>

          {/* Environment */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-200 block font-sans">
              Environment
            </label>
            <select
              value={environment}
              onChange={e => setEnvironment(e.target.value as Environment)}
              className="w-full px-3 py-2 rounded-lg bg-black/50 border border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-100 text-xs font-mono outline-none"
            >
              <option value="Production">Production</option>
              <option value="Staging">Staging</option>
              <option value="Development">Development</option>
            </select>
          </div>

          {/* Alert Source */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-200 block font-sans">
              Alert Source
            </label>
            <select
              value={alertSource}
              onChange={e => setAlertSource(e.target.value as AlertSource)}
              className="w-full px-3 py-2 rounded-lg bg-black/50 border border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-100 text-xs font-mono outline-none"
            >
              <option value="PagerDuty">PagerDuty</option>
              <option value="Datadog">Datadog</option>
              <option value="Prometheus">Prometheus</option>
              <option value="CloudWatch">CloudWatch</option>
              <option value="Manual">Manual</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>

        {/* Description */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-200 block font-sans">
            Incident Description & Context
          </label>
          <textarea
            rows={3}
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Explain what is failing, user impact, affected routes, or symptoms..."
            className="w-full px-3.5 py-2.5 rounded-lg bg-black/50 border border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-200 placeholder:text-slate-400 text-xs font-sans leading-relaxed outline-none"
          />
        </div>

        {/* Logs & Stack Trace (code textarea) */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 font-sans">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>Logs / Stack Trace / Error Payload</span>
            </label>
            <span className="text-[11px] font-mono text-slate-400">
              Monospace Code Ingestion
            </span>
          </div>
          <textarea
            rows={8}
            value={logs}
            onChange={e => setLogs(e.target.value)}
            placeholder="Paste application stack traces, container exit codes, or alert metrics..."
            className="w-full px-3.5 py-2.5 rounded-lg bg-[#070b12] border border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-cyan-200 text-xs font-mono leading-relaxed outline-none select-text"
          />
        </div>

        {/* Action Button & Loading States */}
        <div className="pt-2">
          {isAnalyzing ? (
            <div className="rounded-xl border border-cyan-500/40 bg-cyan-950/20 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BrainCircuit className="w-5 h-5 text-cyan-400 animate-spin" />
                  <span className="text-sm font-mono font-semibold text-cyan-300">
                    AI SRE Agent Ingestion in Progress...
                  </span>
                </div>
                <span className="text-xs font-mono text-cyan-400">
                  RAG Pipeline Active
                </span>
              </div>

              {/* Step ticker */}
              <div className="space-y-1.5 pt-1">
                {loadingSteps.map((step, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs font-mono text-slate-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                    <span>{step}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <button
              type="submit"
              className="w-full py-3 rounded-lg bg-gradient-to-r from-cyan-500 via-indigo-600 to-violet-600 hover:from-cyan-400 hover:via-indigo-500 hover:to-violet-500 text-white font-semibold text-sm shadow-xl shadow-cyan-950/60 transition-all flex items-center justify-center gap-2 cursor-pointer font-sans"
            >
              <Sparkles className="w-4 h-4 fill-current" />
              <span>Analyze Incident</span>
            </button>
          )}
        </div>
      </form>
    </div>
  );
};
