import React from 'react';
import { IncidentMemory, SimilarIncident } from '../../types/incident';
import { X, CheckCircle2, Database, Clock, Terminal, FileText, Sparkles, BookOpen } from 'lucide-react';
import { SeverityBadge } from '../common/SeverityBadge';

interface PostMortemModalProps {
  isOpen: boolean;
  onClose: () => void;
  memory: IncidentMemory | SimilarIncident | null;
}

export const PostMortemModal: React.FC<PostMortemModalProps> = ({ isOpen, onClose, memory }) => {
  if (!isOpen || !memory) return null;

  const isFullMemory = 'symptoms' in memory;
  const mem = memory as IncidentMemory;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl rounded-xl border border-slate-700 bg-[#0d1322] shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-[#0a0f1c] border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center">
              <FileText className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-slate-100 text-base font-sans">
                  Post-Mortem & Memory Record
                </h3>
                {memory.isLiveLearned && (
                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-400 border border-emerald-600/40">
                    Learned from Live Incident
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Indexed in organizational knowledge base with 384-dimensional vector embedding
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs font-sans">
          {/* Title banner */}
          <div className="rounded-lg bg-slate-900/80 border border-slate-800 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                {memory.service}
              </span>
              <SeverityBadge severity={memory.severity} size="sm" />
            </div>
            <h4 className="text-base font-semibold text-slate-100 font-sans">
              {'incidentTitle' in memory ? memory.incidentTitle : memory.title}
            </h4>
            <div className="flex items-center gap-4 text-slate-400 text-xs font-mono pt-1">
              <span>Date: {'createdAt' in memory ? memory.createdAt?.slice(0, 10) : memory.date}</span>
              <span>Time to Resolve: {memory.timeToResolutionMinutes} mins</span>
              <span className="text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Resolution Verified
              </span>
            </div>
          </div>

          {/* Symptoms if full memory */}
          {isFullMemory && mem.symptoms && mem.symptoms.length > 0 && (
            <div className="rounded-lg bg-slate-900/60 border border-slate-800/80 p-3.5 space-y-2">
              <span className="font-mono text-cyan-300 font-semibold text-[11px] uppercase tracking-wider block">
                Observed Symptoms & Signatures:
              </span>
              <ul className="space-y-1 text-slate-300">
                {mem.symptoms.map((s, idx) => (
                  <li key={idx} className="flex items-center gap-1.5 font-mono text-[11px]">
                    <span className="text-cyan-400">•</span>
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Root cause */}
          <div className="rounded-lg bg-slate-900/60 border border-slate-800/80 p-3.5 space-y-1.5">
            <span className="font-mono text-amber-300 font-semibold text-[11px] uppercase tracking-wider block">
              Verified Root Cause:
            </span>
            <p className="text-slate-200 text-xs leading-relaxed font-sans">
              {memory.rootCause}
            </p>
          </div>

          {/* Resolution */}
          <div className="rounded-lg bg-slate-900/60 border border-slate-800/80 p-3.5 space-y-1.5">
            <span className="font-mono text-emerald-300 font-semibold text-[11px] uppercase tracking-wider block">
              Successful Resolution:
            </span>
            <p className="text-slate-200 text-xs leading-relaxed font-sans">
              {memory.resolution}
            </p>
          </div>

          {/* Runbook Used */}
          <div className="rounded-lg bg-slate-900/60 border border-slate-800/80 p-3.5 space-y-2">
            <div className="flex items-center gap-2">
              <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-mono text-slate-300 font-semibold text-[11px]">
                Runbook: <strong className="text-cyan-300">{'runbook' in memory ? memory.runbook : memory.runbookName}</strong>
              </span>
            </div>

            {isFullMemory && mem.runbookCommands && mem.runbookCommands.length > 0 && (
              <div className="space-y-1 pt-1">
                {mem.runbookCommands.map((cmd, idx) => (
                  <div key={idx} className="bg-black/60 rounded px-2.5 py-1 font-mono text-[11px] text-cyan-400 border border-slate-800">
                    <code>{cmd}</code>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Engineer Feedback */}
          {isFullMemory && mem.engineerFeedback && (
            <div className="rounded-lg bg-indigo-950/20 border border-indigo-900/40 p-3.5 space-y-1.5">
              <span className="font-mono text-indigo-300 font-semibold text-[11px] uppercase tracking-wider block">
                Engineer Post-Mortem Feedback & Agent Takeaway:
              </span>
              <p className="text-slate-300 text-xs leading-relaxed italic font-sans">
                &ldquo;{mem.engineerFeedback}&rdquo;
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0a0f1c] border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs transition-colors"
          >
            Close Post-Mortem
          </button>
        </div>
      </div>
    </div>
  );
};
