import React, { useState } from 'react';
import { RemediationStage, RemediationStep } from '../../types/incident';
import { CheckSquare, Square, Copy, Check, Terminal, ShieldAlert, AlertTriangle } from 'lucide-react';

interface RemediationPlanViewProps {
  stages: RemediationStage[];
  onToggleStep: (stepId: string, completed: boolean) => void;
}

export const RemediationPlanView: React.FC<RemediationPlanViewProps> = ({
  stages,
  onToggleStep
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Calculate completion progress
  let totalSteps = 0;
  let completedSteps = 0;
  stages.forEach(stage => {
    stage.steps.forEach(step => {
      totalSteps++;
      if (step.completed) completedSteps++;
    });
  });
  const progressPercent = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-5 shadow-lg space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
            <CheckSquare className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-sm font-sans tracking-wide">
              Recommended Remediation Plan
            </h3>
            <p className="text-xs text-slate-400">
              Interactive 4-stage action plan prioritized by historical resolution efficacy
            </p>
          </div>
        </div>

        {/* Progress meter */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-xs font-mono text-slate-400">Execution Progress: </span>
            <span className="text-xs font-mono font-bold text-emerald-400">
              {completedSteps} / {totalSteps} ({progressPercent}%)
            </span>
          </div>
          <div className="w-24 bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700/60">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Stages list */}
      <div className="space-y-4">
        {stages.map(stage => (
          <div
            key={stage.stageNumber}
            className="rounded-xl border border-slate-800/90 bg-[#090e1a]/80 overflow-hidden"
          >
            {/* Stage Header */}
            <div className="px-4 py-2.5 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
              <span className="font-semibold text-xs font-mono text-cyan-300 uppercase tracking-wider">
                {stage.stageName}
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                {stage.steps.filter(s => s.completed).length} / {stage.steps.length} done
              </span>
            </div>

            {/* Stage Steps */}
            <div className="divide-y divide-slate-800/60">
              {stage.steps.map(step => (
                <div
                  key={step.id}
                  className={`p-3.5 transition-colors flex items-start gap-3 ${
                    step.completed ? 'bg-emerald-950/10 opacity-75' : 'hover:bg-slate-900/50'
                  }`}
                >
                  {/* Step checkbox */}
                  <button
                    onClick={() => onToggleStep(step.id, !step.completed)}
                    className="mt-0.5 text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer shrink-0"
                  >
                    {step.completed ? (
                      <CheckSquare className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-500 hover:text-slate-300" />
                    )}
                  </button>

                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <p
                        className={`text-xs font-sans leading-relaxed ${
                          step.completed ? 'text-slate-400 line-through' : 'text-slate-200'
                        }`}
                      >
                        {step.description}
                      </p>

                      {/* Risk Badge */}
                      {step.riskLevel === 'caution' && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-800/50 shrink-0">
                          <AlertTriangle className="w-2.5 h-2.5" />
                          Caution
                        </span>
                      )}
                    </div>

                    {/* Optional Command Block */}
                    {step.command && (
                      <div className="flex items-center justify-between bg-black/60 rounded-lg border border-slate-800 px-3 py-1.5 font-mono text-xs text-cyan-300 overflow-x-auto group">
                        <div className="flex items-center gap-2 min-w-0">
                          <Terminal className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          <code className="truncate select-all">{step.command}</code>
                        </div>
                        <button
                          onClick={() => handleCopy(step.id, step.command!)}
                          title="Copy command"
                          className="ml-2 text-slate-400 hover:text-white p-1 rounded transition-colors shrink-0"
                        >
                          {copiedId === step.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
