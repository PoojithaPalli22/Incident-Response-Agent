import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { CheckCircle2, X, BrainCircuit, Sparkles, Star, Clock } from 'lucide-react';
import { Incident } from '../../types/incident';

interface ResolveModalProps {
  isOpen: boolean;
  onClose: () => void;
  incident: Incident;
  onSaveToMemory: (data: {
    actualFix: string;
    utilityRating: 'Very useful' | 'Useful' | 'Partially useful' | 'Not useful';
    actualRootCause: string;
    agentMemoryTakeaway: string;
    resolutionTimeMinutes: number;
  }) => Promise<void>;
}

export const ResolveModal: React.FC<ResolveModalProps> = ({
  isOpen,
  onClose,
  incident,
  onSaveToMemory
}) => {
  const [actualFix, setActualFix] = useState(
    incident.recommendedRunbook
      ? `Executed ${incident.recommendedRunbook.name}: Rollback deployment to prior stable version and restarted pods.`
      : 'Deployment rollback and restart of affected pods to release orphaned connections.'
  );
  const [utilityRating, setUtilityRating] = useState<'Very useful' | 'Useful' | 'Partially useful' | 'Not useful'>('Very useful');
  const [actualRootCause, setActualRootCause] = useState(
    incident.probableRootCause?.description || 'Database connection leak introduced in recent deployment revision.'
  );
  const [agentMemoryTakeaway, setAgentMemoryTakeaway] = useState(
    'Always inspect session cleanup and connection pool acquire timeouts when payment-api latencies degrade above 5 seconds.'
  );
  const [resolutionTimeMinutes, setResolutionTimeMinutes] = useState(7);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await onSaveToMemory({
        actualFix,
        utilityRating,
        actualRootCause,
        agentMemoryTakeaway,
        resolutionTimeMinutes
      });

      // Celebration effect
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (err) {
        // Fallback silently if canvas context unavailable
      }

      onClose();
    } catch (err) {
      console.error('Failed to resolve incident:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl rounded-xl border border-slate-700 bg-[#0d1322] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#0a0f1c] border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100 text-base font-sans">
                Resolve Incident & Save to Organizational Memory
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Index post-mortem into Vector DB to improve future incident responses
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs font-sans">
          {/* Target Service info banner */}
          <div className="rounded-lg bg-slate-900/80 border border-slate-800 p-3 flex items-center justify-between font-mono text-xs">
            <div className="space-y-0.5">
              <span className="text-slate-400">Incident:</span>{' '}
              <strong className="text-slate-200">{incident.title}</strong>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                {incident.service}
              </span>
              <span className="px-2 py-0.5 rounded bg-rose-950/60 text-rose-300 border border-rose-800/40">
                {incident.severity}
              </span>
            </div>
          </div>

          {/* 1. What actually fixed the incident? */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-200 block">
              1. What actually fixed the incident? <span className="text-rose-400">*</span>
            </label>
            <textarea
              required
              rows={2}
              value={actualFix}
              onChange={e => setActualFix(e.target.value)}
              placeholder="e.g. Rolled back deployment to v2.4.0 and restarted affected pods."
              className="w-full px-3 py-2 rounded-lg bg-black/50 border border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-200 placeholder:text-slate-400 text-xs font-mono outline-none"
            />
          </div>

          {/* 2. Was the AI recommendation useful? */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-200 block">
              2. Was the AI recommendation useful?
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['Very useful', 'Useful', 'Partially useful', 'Not useful'] as const).map(option => (
                <button
                  type="button"
                  key={option}
                  onClick={() => setUtilityRating(option)}
                  className={`px-3 py-2 rounded-lg border text-xs font-mono transition-all flex items-center justify-center gap-1.5 ${
                    utilityRating === option
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-sm font-semibold'
                      : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <Star className={`w-3 h-3 ${utilityRating === option ? 'text-cyan-400 fill-current' : 'text-slate-500'}`} />
                  <span>{option}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 3. What was the actual root cause? */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-200 block">
              3. What was the actual root cause?
            </label>
            <textarea
              rows={2}
              value={actualRootCause}
              onChange={e => setActualRootCause(e.target.value)}
              placeholder="e.g. Unclosed database session in asynchronous transaction callback."
              className="w-full px-3 py-2 rounded-lg bg-black/50 border border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-200 placeholder:text-slate-400 text-xs font-mono outline-none"
            />
          </div>

          {/* 4. What should the agent remember? */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-200 block flex items-center gap-1.5">
              <BrainCircuit className="w-3.5 h-3.5 text-purple-400" />
              <span>4. What should the agent remember for future incidents?</span>
            </label>
            <textarea
              rows={2}
              value={agentMemoryTakeaway}
              onChange={e => setAgentMemoryTakeaway(e.target.value)}
              placeholder="Lessons learned to retain in organizational vector memory..."
              className="w-full px-3 py-2 rounded-lg bg-black/50 border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-slate-200 placeholder:text-slate-400 text-xs font-mono outline-none"
            />
          </div>

          {/* 5. Resolution time */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-200 flex items-center justify-between">
              <span>5. Time to Resolution (minutes)</span>
              <span className="font-mono text-cyan-400">{resolutionTimeMinutes} minutes</span>
            </label>
            <input
              type="number"
              min={1}
              max={300}
              value={resolutionTimeMinutes}
              onChange={e => setResolutionTimeMinutes(parseInt(e.target.value, 10) || 7)}
              className="w-full px-3 py-2 rounded-lg bg-black/50 border border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-200 text-xs font-mono outline-none"
            />
          </div>

          {/* Footer Controls */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
            <div className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Vector embedding will be generated automatically</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg border border-slate-700 hover:border-slate-600 bg-slate-800/80 hover:bg-slate-800 text-slate-300 font-mono text-xs transition-colors"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-2 px-5 py-2 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-mono text-xs font-semibold shadow-lg shadow-emerald-950/60 transition-all cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Indexing Vector Memory...</span>
                  </>
                ) : (
                  <>
                    <BrainCircuit className="w-4 h-4" />
                    <span>Save to Memory</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
