import React, { useState } from 'react';
import { RecommendedRunbook } from '../../types/incident';
import { BookOpen, Copy, Check, Terminal, Play, AlertTriangle, ShieldCheck } from 'lucide-react';

interface RunbookCardProps {
  runbook: RecommendedRunbook;
  onRunSimulation: () => void;
}

export const RunbookCard: React.FC<RunbookCardProps> = ({ runbook, onRunSimulation }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCopy = (idx: number, command: string) => {
    navigator.clipboard.writeText(command);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-5 shadow-lg space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center">
            <BookOpen className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-sm font-sans tracking-wide">
              Recommended Runbook
            </h3>
            <p className="text-xs text-slate-400">
              Standard operating procedure indexed from past successful resolutions
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2.5 py-1 rounded-full">
            Success Rate: {Math.round(runbook.successRate * 100)}%
          </span>
          <button
            onClick={onRunSimulation}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-mono text-xs font-semibold shadow-md shadow-cyan-950/40 transition-all cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Run in Simulation</span>
          </button>
        </div>
      </div>

      {/* Runbook Info Card */}
      <div className="rounded-lg bg-slate-900/90 border border-slate-800 p-4 space-y-2">
        <div className="flex items-center justify-between">
          <h4 className="font-semibold text-sm text-cyan-300 font-mono">
            {runbook.name}
          </h4>
          <span className="text-[11px] font-mono text-slate-400">
            Target: {runbook.targetService}
          </span>
        </div>
        <p className="text-xs font-sans text-slate-300 leading-relaxed">
          {runbook.description}
        </p>
      </div>

      {/* Safety Warning Banner (Requirement 10) */}
      <div className="rounded-lg bg-amber-950/20 border border-amber-800/40 p-3 flex items-start gap-2.5 text-xs text-amber-300/90 font-sans">
        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          {runbook.warning || '⚠ These commands are suggestions generated from historical runbooks. Review them before executing against production.'}
        </p>
      </div>

      {/* Step by Step Runbook */}
      <div className="space-y-2">
        <span className="text-xs font-mono uppercase text-slate-400 font-semibold block">
          Runbook Procedure & Commands:
        </span>
        <div className="space-y-2">
          {runbook.commands.map((cmd, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between bg-black/60 rounded-lg border border-slate-800 px-3.5 py-2 font-mono text-xs text-cyan-300 group"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="text-slate-400 select-none text-[11px] font-mono w-4">
                  {idx + 1}.
                </span>
                <code className="truncate select-all">{cmd}</code>
              </div>
              <button
                onClick={() => handleCopy(idx, cmd)}
                title="Copy command"
                className="ml-2 text-slate-400 hover:text-white p-1 rounded transition-colors shrink-0"
              >
                {copiedIndex === idx ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
