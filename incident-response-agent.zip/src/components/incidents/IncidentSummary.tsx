import React from 'react';
import { Incident } from '../../types/incident';
import { SeverityBadge } from '../common/SeverityBadge';
import { StatusBadge } from '../common/StatusBadge';
import { Clock, Server, Globe, AlertOctagon, Terminal } from 'lucide-react';

interface IncidentSummaryProps {
  incident: Incident;
  onMarkResolved: () => void;
  onAnalyzeAgain?: () => void;
  isAnalyzing?: boolean;
}

export const IncidentSummary: React.FC<IncidentSummaryProps> = ({
  incident,
  onMarkResolved,
  onAnalyzeAgain,
  isAnalyzing
}) => {
  return (
    <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-5 shadow-lg space-y-4">
      {/* Top action row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
        <div className="flex flex-wrap items-center gap-2.5">
          <SeverityBadge severity={incident.severity} size="lg" />
          <StatusBadge status={incident.status} />
          <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            Detected at {incident.createdAt ? new Date(incident.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '14:32'}
          </span>
          <span className="text-xs font-mono text-slate-400">
            Source: <strong className="text-slate-300">{incident.alertSource}</strong>
          </span>
        </div>

        <div className="flex items-center gap-2">
          {onAnalyzeAgain && (
            <button
              onClick={onAnalyzeAgain}
              disabled={isAnalyzing}
              className="px-3.5 py-1.5 rounded-lg border border-slate-700 hover:border-slate-600 bg-slate-800/60 hover:bg-slate-800 text-xs font-mono text-slate-300 transition-colors disabled:opacity-50"
            >
              {isAnalyzing ? 'Re-analyzing...' : 'Re-run AI Analysis'}
            </button>
          )}

          {incident.status !== 'resolved' ? (
            <button
              onClick={onMarkResolved}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-semibold shadow-md shadow-emerald-950/60 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>Mark as Resolved</span>
            </button>
          ) : (
            <span className="px-3 py-1 rounded-lg bg-emerald-950/50 border border-emerald-500/40 text-xs font-mono text-emerald-300 flex items-center gap-1.5">
              <span>✓ Resolved & Stored in Memory</span>
            </span>
          )}
        </div>
      </div>

      {/* Title & Service metadata */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded bg-slate-800/90 text-cyan-300 border border-slate-700 text-xs font-mono flex items-center gap-1">
            <Server className="w-3 h-3 text-cyan-400" />
            {incident.service}
          </span>
          <span className="px-2.5 py-0.5 rounded bg-slate-800/90 text-slate-300 border border-slate-700 text-xs font-mono flex items-center gap-1">
            <Globe className="w-3 h-3 text-slate-400" />
            {incident.environment}
          </span>
        </div>

        <h1 className="text-xl md:text-2xl font-bold text-slate-100 font-sans tracking-tight">
          {incident.title}
        </h1>

        <p className="text-xs text-slate-300 font-sans leading-relaxed">
          {incident.description}
        </p>
      </div>

      {/* Error Type Badge & Symptoms */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
        {incident.errorType && (
          <div className="rounded-lg bg-rose-950/20 border border-rose-900/40 p-3 flex items-start gap-2 text-xs">
            <AlertOctagon className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-mono text-rose-400 font-semibold block text-[11px] uppercase tracking-wider">
                Detected Error Signature:
              </span>
              <code className="font-mono text-rose-200 text-xs block break-all">
                {incident.errorType}
              </code>
            </div>
          </div>
        )}

        {incident.detectedSymptoms && incident.detectedSymptoms.length > 0 && (
          <div className="rounded-lg bg-slate-900/60 border border-slate-800/80 p-3 space-y-1.5">
            <span className="font-mono text-cyan-300 font-semibold text-[11px] uppercase tracking-wider block">
              Detected Symptoms:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {incident.detectedSymptoms.map((sym, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-mono text-[11px]"
                >
                  {sym}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Collapsible raw logs preview */}
      {incident.logs && (
        <details className="group rounded-lg bg-black/60 border border-slate-800/90 text-xs font-mono">
          <summary className="px-3.5 py-2 cursor-pointer text-slate-400 hover:text-slate-200 flex items-center justify-between select-none">
            <div className="flex items-center gap-2">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>Raw Ingested Logs & Stack Trace</span>
            </div>
            <span className="text-[11px] text-slate-500 group-open:rotate-180 transition-transform">▼</span>
          </summary>
          <div className="px-3.5 pb-3 pt-1 border-t border-slate-800 text-slate-300 overflow-x-auto select-all max-h-48 whitespace-pre">
            {incident.logs}
          </div>
        </details>
      )}
    </div>
  );
};
