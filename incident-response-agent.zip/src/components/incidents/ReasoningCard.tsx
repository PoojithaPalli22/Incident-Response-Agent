import React from 'react';
import { Lightbulb, CheckCircle2, ShieldCheck, Database } from 'lucide-react';

interface ReasoningCardProps {
  reasoning: string;
  matchedCount?: number;
  confidence?: number;
}

export const ReasoningCard: React.FC<ReasoningCardProps> = ({
  reasoning,
  matchedCount = 3,
  confidence = 0.94
}) => {
  return (
    <div className="rounded-xl border border-indigo-500/30 bg-gradient-to-br from-[#0e1629] via-[#0d1322] to-[#080d18] p-5 shadow-lg shadow-indigo-950/20 relative overflow-hidden">
      {/* Subtle ambient glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center">
            <Lightbulb className="w-4 h-4 text-indigo-300" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-sm font-sans tracking-wide">
              Why This Recommendation?
            </h3>
            <p className="text-xs text-slate-400">
              Correlated with organizational incident memory & historical precedents
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/50 border border-emerald-500/40 text-xs font-mono text-emerald-300">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Confidence: {confidence >= 0.85 ? 'High' : 'Moderate'} ({Math.round(confidence * 100)}%)</span>
          </div>
        </div>
      </div>

      <div className="rounded-lg bg-slate-900/70 border border-slate-800/80 p-4 font-sans text-sm text-slate-300 leading-relaxed">
        {reasoning}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-3 border-t border-slate-800/60">
        <div className="flex items-center gap-1.5">
          <Database className="w-3.5 h-3.5 text-cyan-400" />
          <span>Retrieved Context: <strong className="text-slate-200">{matchedCount} historical memories</strong></span>
        </div>
        <div className="flex items-center gap-1.5">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>Historical Fix Success: <strong className="text-emerald-400">100%</strong></span>
        </div>
        <div className="text-slate-400">
          Source: Vector Knowledge Base
        </div>
      </div>
    </div>
  );
};
