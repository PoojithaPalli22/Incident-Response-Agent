import React, { useState } from 'react';
import { Incident, SimilarIncident, AgentActivityStep } from '../../types/incident';
import { IncidentSummary } from './IncidentSummary';
import { AiActivityBar } from './AiActivityBar';
import { ReasoningCard } from './ReasoningCard';
import { SimilarIncidentsList } from './SimilarIncidentsList';
import { ProbableRootCauseCard } from './ProbableRootCauseCard';
import { RemediationPlanView } from './RemediationPlanView';
import { RunbookCard } from './RunbookCard';
import { TimelineView } from './TimelineView';
import { SimulationModal } from './SimulationModal';
import { ResolveModal } from './ResolveModal';
import { PostMortemModal } from './PostMortemModal';
import { ArrowLeft, Sparkles, CheckCircle2 } from 'lucide-react';

interface IncidentDetailViewProps {
  incident: Incident;
  activitySteps?: AgentActivityStep[];
  onBack: () => void;
  onToggleStep: (stepId: string, completed: boolean) => void;
  onSimulate: () => Promise<void>;
  onResolve: (data: any) => Promise<void>;
  onReanalyze?: () => Promise<void>;
  isAnalyzing?: boolean;
}

export const IncidentDetailView: React.FC<IncidentDetailViewProps> = ({
  incident,
  activitySteps = [],
  onBack,
  onToggleStep,
  onSimulate,
  onResolve,
  onReanalyze,
  isAnalyzing = false
}) => {
  const [isSimulationOpen, setIsSimulationOpen] = useState(false);
  const [isResolveOpen, setIsResolveOpen] = useState(false);
  const [selectedPostMortem, setSelectedPostMortem] = useState<SimilarIncident | null>(null);

  const handleSimulationCompleted = async () => {
    await onSimulate();
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Back button and quick navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-mono text-slate-400 hover:text-cyan-300 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Incidents</span>
        </button>

        {incident.status === 'resolved' && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-xs font-mono text-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Learned & Stored in Vector Memory</span>
          </div>
        )}
      </div>

      {/* 1. Incident Summary Header (Requirement 5) */}
      <IncidentSummary
        incident={incident}
        onMarkResolved={() => setIsResolveOpen(true)}
        onAnalyzeAgain={onReanalyze}
        isAnalyzing={isAnalyzing}
      />

      {/* 2. AI Observability Activity Bar (Requirement 29) */}
      {activitySteps.length > 0 && (
        <AiActivityBar steps={activitySteps} isAnalyzing={isAnalyzing} />
      )}

      {/* 3. "Why This Recommendation?" Section (Requirement 7) */}
      {incident.reasoningContext && (
        <ReasoningCard
          reasoning={incident.reasoningContext}
          matchedCount={incident.similarIncidents?.length || 3}
          confidence={incident.probableRootCause?.confidence || 0.94}
        />
      )}

      {/* 4. Similar Incidents From Memory (Requirement 6) */}
      {incident.similarIncidents && incident.similarIncidents.length > 0 && (
        <SimilarIncidentsList
          incidents={incident.similarIncidents}
          onOpenPostMortem={inc => setSelectedPostMortem(inc)}
        />
      )}

      {/* 5. Probable Root Cause Section (Requirement 9) */}
      {incident.probableRootCause && (
        <ProbableRootCauseCard rootCause={incident.probableRootCause} />
      )}

      {/* 6. Interactive Remediation Plan (Requirement 8) */}
      {incident.remediationStages && incident.remediationStages.length > 0 && (
        <RemediationPlanView
          stages={incident.remediationStages}
          onToggleStep={onToggleStep}
        />
      )}

      {/* 7. Recommended Runbook (Requirement 10 & 11) */}
      {incident.recommendedRunbook && (
        <RunbookCard
          runbook={incident.recommendedRunbook}
          onRunSimulation={() => setIsSimulationOpen(true)}
        />
      )}

      {/* 8. Incident Timeline (Requirement 12) */}
      {incident.timeline && incident.timeline.length > 0 && (
        <TimelineView events={incident.timeline} />
      )}

      {/* Simulation Terminal Modal */}
      <SimulationModal
        isOpen={isSimulationOpen}
        onClose={() => setIsSimulationOpen(false)}
        service={incident.service}
        runbookName={incident.recommendedRunbook?.name || 'Recovery Runbook'}
        commands={incident.recommendedRunbook?.commands || []}
        onSimulationCompleted={handleSimulationCompleted}
      />

      {/* Resolve Incident & Feedback Loop Modal (Requirements 13 & 14) */}
      <ResolveModal
        isOpen={isResolveOpen}
        onClose={() => setIsResolveOpen(false)}
        incident={incident}
        onSaveToMemory={onResolve}
      />

      {/* Historical Post-Mortem Viewer Modal */}
      <PostMortemModal
        isOpen={!!selectedPostMortem}
        onClose={() => setSelectedPostMortem(null)}
        memory={selectedPostMortem}
      />
    </div>
  );
};
