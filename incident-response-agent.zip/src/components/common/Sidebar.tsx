import React from 'react';
import {
  LayoutDashboard,
  AlertTriangle,
  Database,
  BookOpen,
  Network,
  Settings,
  CircleDot,
  CheckCircle2,
  BrainCircuit,
  Radio
} from 'lucide-react';

export type NavTab = 'dashboard' | 'new-incident' | 'incidents' | 'memory' | 'runbooks' | 'architecture' | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  activeIncidentsCount: number;
  memoriesCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  activeIncidentsCount,
  memoriesCount
}) => {
  const navItems = [
    {
      id: 'dashboard' as NavTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'incidents' as NavTab,
      label: 'Incidents',
      icon: AlertTriangle,
      badge: activeIncidentsCount > 0 ? `${activeIncidentsCount} active` : null,
      badgeColor: 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
    },
    {
      id: 'memory' as NavTab,
      label: 'Incident Memory',
      icon: Database,
      badge: `${memoriesCount}`,
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
    },
    {
      id: 'runbooks' as NavTab,
      label: 'Runbooks',
      icon: BookOpen,
      badge: '4'
    },
    {
      id: 'architecture' as NavTab,
      label: 'Architecture',
      icon: Network,
      badge: null
    },
    {
      id: 'settings' as NavTab,
      label: 'Settings',
      icon: Settings,
      badge: null
    }
  ];

  return (
    <aside className="w-64 border-r border-slate-800/80 bg-[#080c14] flex flex-col justify-between shrink-0 select-none">
      <div className="p-4 space-y-6">
        {/* Navigation list */}
        <nav className="space-y-1">
          <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 px-3 py-2 font-semibold">
            Operations & AI SRE
          </div>
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all text-left ${
                  isActive
                    ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 shadow-sm shadow-cyan-950/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[11px] font-mono px-2 py-0.5 rounded-full ${
                      item.badgeColor || 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Persistent Connection Status Card (Requirement 26) */}
      <div className="p-4 m-3 rounded-xl border border-slate-800/90 bg-[#0b101c] shadow-inner space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-4 h-4 text-cyan-400 animate-pulse" />
            <span className="text-xs font-semibold text-slate-200 font-mono">AI Agent Status</span>
          </div>
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
        </div>

        <div className="space-y-1.5 text-xs font-mono">
          <div className="flex items-center justify-between text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              Memory Store:
            </span>
            <span className="text-emerald-400 font-medium">Connected</span>
          </div>

          <div className="flex items-center justify-between text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              Vector DB:
            </span>
            <span className="text-cyan-400 font-medium">Connected</span>
          </div>

          <div className="flex items-center justify-between text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
              LLM Orchestrator:
            </span>
            <span className="text-purple-400 font-medium">Connected</span>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-800/70 text-[10px] text-slate-400 font-mono flex items-center justify-between">
          <span>Engine: Hybrid RAG</span>
          <span className="text-slate-400">v2.4-active</span>
        </div>
      </div>
    </aside>
  );
};
