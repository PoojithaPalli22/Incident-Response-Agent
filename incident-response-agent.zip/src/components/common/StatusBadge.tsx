import React from 'react';
import { IncidentStatus } from '../../types/incident';

interface StatusBadgeProps {
  status: IncidentStatus;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const configs: Record<IncidentStatus, { label: string; style: string; dot: string }> = {
    detected: {
      label: 'Detected',
      style: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
      dot: 'bg-rose-500 animate-ping'
    },
    analyzing: {
      label: 'AI Analyzing...',
      style: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
      dot: 'bg-purple-400 animate-spin'
    },
    action_required: {
      label: 'Action Required',
      style: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
      dot: 'bg-amber-400'
    },
    mitigating: {
      label: 'Mitigating (Simulated)',
      style: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
      dot: 'bg-cyan-400'
    },
    resolved: {
      label: 'Resolved & Indexed',
      style: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      dot: 'bg-emerald-400'
    }
  };

  const current = configs[status] || configs.detected;

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border font-mono ${current.style}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${current.dot}`} />
      {current.label}
    </span>
  );
};
