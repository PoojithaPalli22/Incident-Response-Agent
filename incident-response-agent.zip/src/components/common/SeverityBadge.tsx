import React from 'react';
import { Severity } from '../../types/incident';

interface SeverityBadgeProps {
  severity: Severity;
  size?: 'sm' | 'md' | 'lg';
}

export const SeverityBadge: React.FC<SeverityBadgeProps> = ({ severity, size = 'md' }) => {
  const styles: Record<Severity, string> = {
    'SEV-1': 'bg-rose-500/15 text-rose-400 border-rose-500/30',
    'SEV-2': 'bg-amber-500/15 text-amber-400 border-amber-500/30',
    'SEV-3': 'bg-yellow-500/15 text-yellow-300 border-yellow-500/30',
    'SEV-4': 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30'
  };

  const dotColors: Record<Severity, string> = {
    'SEV-1': 'bg-rose-400 animate-pulse',
    'SEV-2': 'bg-amber-400',
    'SEV-3': 'bg-yellow-300',
    'SEV-4': 'bg-cyan-400'
  };

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5 font-semibold',
    lg: 'text-sm px-3 py-1.5 gap-2 font-bold'
  };

  return (
    <span
      className={`inline-flex items-center rounded-md border font-mono tracking-wider ${styles[severity] || styles['SEV-2']} ${sizeClasses[size]}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${dotColors[severity] || 'bg-slate-400'}`} />
      {severity}
    </span>
  );
};
