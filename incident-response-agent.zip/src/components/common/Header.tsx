import React from 'react';
import {
  ShieldAlert,
  PlusCircle,
  Database,
  Cpu,
  RotateCcw,
  Sparkles
} from 'lucide-react';

interface HeaderProps {
  onNewIncident: () => void;
  onResetData: () => void;
  memoriesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onNewIncident,
  onResetData,
  memoriesCount
}) => {
  return (
    <header className="h-16 border-b border-slate-800/80 bg-[#080c14]/90 backdrop-blur-md px-6 flex items-center justify-between sticky top-0 z-30">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-cyan-600 via-indigo-600 to-violet-600 p-[1px] shadow-lg shadow-cyan-950/40">
          <div className="w-full h-full bg-[#0d1321] rounded-lg flex items-center justify-center">
            <ShieldAlert className="w-5 h-5 text-cyan-400" />
          </div>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-100 tracking-tight text-base font-sans">
              Incident Response Agent
            </span>
            <span className="text-[10px] uppercase font-mono font-semibold px-2 py-0.5 rounded bg-cyan-950/60 text-cyan-400 border border-cyan-800/50">
              AI SRE Memory
            </span>
          </div>
          <p className="text-xs text-slate-400 hidden sm:block">
            Autonomous Incident Memory & Retrieval-Augmented Remediation
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Status Pills */}
        <div className="hidden lg:flex items-center gap-2 border border-slate-800 bg-slate-900/60 rounded-full px-3 py-1 text-xs font-mono text-slate-300">
          <Database className="w-3.5 h-3.5 text-cyan-400" />
          <span>Vector Store:</span>
          <span className="text-cyan-400 font-semibold">{memoriesCount} Memories</span>
        </div>

        <div className="hidden md:flex items-center gap-2 border border-slate-800 bg-slate-900/60 rounded-full px-3 py-1 text-xs font-mono text-slate-300">
          <Cpu className="w-3.5 h-3.5 text-emerald-400" />
          <span>LLM:</span>
          <span className="text-emerald-400 font-semibold">Gemini 3.8 Flash</span>
        </div>

        {/* Reset Demo State Button */}
        <button
          onClick={onResetData}
          title="Reset database to initial demo state"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700/60 hover:border-slate-600 bg-slate-800/40 hover:bg-slate-800/80 text-xs text-slate-400 hover:text-slate-200 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Reset Seed</span>
        </button>

        {/* New Incident CTA */}
        <button
          onClick={onNewIncident}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-medium text-xs sm:text-sm shadow-lg shadow-cyan-950/50 hover:shadow-cyan-900/60 transition-all font-sans cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span>+ New Incident</span>
        </button>
      </div>
    </header>
  );
};
