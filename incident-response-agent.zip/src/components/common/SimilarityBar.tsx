import React from 'react';

interface SimilarityBarProps {
  score: number; // 0.0 to 1.0 (e.g. 0.94)
  showPercentage?: boolean;
}

export const SimilarityBar: React.FC<SimilarityBarProps> = ({ score, showPercentage = true }) => {
  const percentage = Math.round(score * 100);

  // Generate ASCII-style meter representation
  const totalBlocks = 18;
  const filledBlocks = Math.round((percentage / 100) * totalBlocks);
  const emptyBlocks = totalBlocks - filledBlocks;
  const asciiMeter = '█'.repeat(filledBlocks) + '░'.repeat(emptyBlocks);

  // Color tone based on match strength
  let colorClass = 'text-cyan-400';
  let bgClass = 'bg-cyan-500';
  if (percentage >= 90) {
    colorClass = 'text-emerald-400';
    bgClass = 'bg-emerald-500';
  } else if (percentage >= 75) {
    colorClass = 'text-cyan-400';
    bgClass = 'bg-cyan-500';
  } else {
    colorClass = 'text-amber-400';
    bgClass = 'bg-amber-500';
  }

  return (
    <div className="flex flex-col gap-1 font-mono text-xs">
      <div className="flex items-center justify-between">
        <span className="text-slate-400">Memory Similarity</span>
        {showPercentage && (
          <span className={`font-bold ${colorClass}`}>
            {percentage}%
          </span>
        )}
      </div>

      {/* Visual meter bar */}
      <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden border border-slate-700/50">
        <div
          className={`h-full rounded-full transition-all duration-500 ${bgClass}`}
          style={{ width: `${percentage}%` }}
        />
      </div>

      {/* ASCII block graphic requested in prompt */}
      <div className="text-[10px] tracking-tighter opacity-70 select-none overflow-hidden text-slate-500 font-mono">
        <span className={colorClass}>{'█'.repeat(filledBlocks)}</span>
        <span>{'░'.repeat(emptyBlocks)}</span>
      </div>
    </div>
  );
};
