import React, { useState } from 'react';
import { Database, Cpu, Shield, RotateCcw, CheckCircle2, HardDrive, Terminal } from 'lucide-react';

interface SettingsViewProps {
  onResetData: () => void;
  memoriesCount: number;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onResetData, memoriesCount }) => {
  const [resetDone, setResetDone] = useState(false);

  const handleReset = () => {
    onResetData();
    setResetDone(true);
    setTimeout(() => setResetDone(false), 3000);
  };

  return (
    <div className="max-w-3xl space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 uppercase font-semibold">
            System Administration
          </span>
        </div>
        <h2 className="text-xl md:text-2xl font-bold text-slate-100 font-sans tracking-tight">
          Agent Settings & Infrastructure Telemetry
        </h2>
        <p className="text-xs text-slate-400 font-sans">
          Manage vector store indexing parameters, LLM orchestration providers, and demo seed state.
        </p>
      </div>

      {/* Cards list */}
      <div className="space-y-4">
        {/* 1. Vector Database Configuration */}
        <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center">
                <Database className="w-4 h-4 text-cyan-400" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-100 text-sm font-sans">
                  Vector Memory Engine
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  In-Memory High-Performance Vector Store
                </p>
              </div>
            </div>

            <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/60 text-emerald-400 border border-emerald-500/30 text-xs font-mono">
              ● Connected
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs font-mono">
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Dimensions</span>
              <strong className="text-slate-200">384-dim Dense</strong>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Indexed Records</span>
              <strong className="text-cyan-400">{memoriesCount} Memories</strong>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Distance Metric</span>
              <strong className="text-slate-200">Cosine Distance</strong>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Retrieval Type</span>
              <strong className="text-purple-300">Hybrid Dense+BM25</strong>
            </div>
          </div>
        </div>

        {/* 2. LLM Provider Status */}
        <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-purple-500/15 border border-purple-500/30 flex items-center justify-center">
                <Cpu className="w-4 h-4 text-purple-400" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-100 text-sm font-sans">
                  AI Orchestrator & Reasoning Engine
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  Primary: Gemini 3.8 Flash | Fallback: SRE Rule Engine
                </p>
              </div>
            </div>

            <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/60 text-emerald-400 border border-emerald-500/30 text-xs font-mono">
              ● Online
            </span>
          </div>

          <p className="text-xs font-sans text-slate-300 leading-relaxed">
            The application dynamically routes analysis prompts through Google GenAI SDK (<code>gemini-3.8-flash</code>) with automatic fallback to our deterministic SRE reasoning engine. This ensures 100% demo uptime and reliability under all network conditions.
          </p>
        </div>

        {/* 3. Reset Demo Data */}
        <div className="rounded-xl border border-rose-950/40 bg-gradient-to-r from-rose-950/10 to-slate-900/40 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-slate-100 text-sm font-sans">
                Reset Demo Data & Seed State
              </h3>
              <p className="text-xs text-slate-400 font-sans">
                Restore initial 15 historical incident memories and clear live-created records.
              </p>
            </div>

            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-300 font-mono text-xs font-semibold transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Seed</span>
            </button>
          </div>

          {resetDone && (
            <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 pt-1">
              <CheckCircle2 className="w-4 h-4" />
              <span>Database successfully reset to initial demo state!</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
