import React, { useState } from 'react';
import { IncidentMemory, Severity } from '../../types/incident';
import { SeverityBadge } from '../common/SeverityBadge';
import { PostMortemModal } from '../incidents/PostMortemModal';
import {
  Database,
  Search,
  CheckCircle2,
  Clock,
  BookOpen,
  Filter,
  Sparkles,
  ExternalLink,
  Tag
} from 'lucide-react';

interface MemoryExplorerViewProps {
  memories: IncidentMemory[];
}

export const MemoryExplorerView: React.FC<MemoryExplorerViewProps> = ({ memories }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedService, setSelectedService] = useState('all');
  const [selectedSeverity, setSelectedSeverity] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedSort, setSelectedSort] = useState<'date' | 'time'>('date');
  const [selectedPostMortem, setSelectedPostMortem] = useState<IncidentMemory | null>(null);

  // Derive unique services & categories
  const services = Array.from(new Set(memories.map(m => m.service)));
  const categories = Array.from(new Set(memories.map(m => m.rootCauseCategory).filter(Boolean)));

  const filtered = memories.filter(m => {
    if (selectedService !== 'all' && m.service !== selectedService) return false;
    if (selectedSeverity !== 'all' && m.severity !== selectedSeverity) return false;
    if (selectedCategory !== 'all' && m.rootCauseCategory !== selectedCategory) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        m.incidentTitle.toLowerCase().includes(q) ||
        m.service.toLowerCase().includes(q) ||
        m.rootCause.toLowerCase().includes(q) ||
        m.resolution.toLowerCase().includes(q) ||
        m.runbook.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Sorting
  filtered.sort((a, b) => {
    if (selectedSort === 'date') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    return a.timeToResolutionMinutes - b.timeToResolutionMinutes;
  });

  return (
    <div className="space-y-5 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-purple-950/70 text-purple-300 border border-purple-800/40 uppercase font-semibold">
              Vector Database Catalog
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-100 font-sans tracking-tight">
            Incident Memory & Organizational Post-Mortems
          </h2>
          <p className="text-xs text-slate-400 font-sans">
            Dense 384-dimensional vector embeddings of all historical outages, verified root causes, and effective runbooks.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto">
          <div className="px-3.5 py-1.5 rounded-lg border border-purple-500/30 bg-purple-950/30 text-xs font-mono text-purple-300 flex items-center gap-1.5">
            <Database className="w-4 h-4 text-purple-400" />
            <span>{memories.length} Memories Indexed</span>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-3.5 space-y-3">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search incident memory by symptom, root cause, service, or resolution..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-lg bg-black/40 border border-slate-700/80 focus:border-cyan-500 text-xs font-mono text-slate-200 placeholder:text-slate-400 outline-none"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 pt-1">
          <div className="flex flex-wrap items-center gap-2">
            {/* Service filter */}
            <select
              value={selectedService}
              onChange={e => setSelectedService(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-black/40 border border-slate-700 text-xs font-mono text-slate-300 outline-none"
            >
              <option value="all">All Services</option>
              {services.map(svc => (
                <option key={svc} value={svc}>{svc}</option>
              ))}
            </select>

            {/* Severity filter */}
            <select
              value={selectedSeverity}
              onChange={e => setSelectedSeverity(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-black/40 border border-slate-700 text-xs font-mono text-slate-300 outline-none"
            >
              <option value="all">All Severities</option>
              <option value="SEV-1">SEV-1</option>
              <option value="SEV-2">SEV-2</option>
              <option value="SEV-3">SEV-3</option>
              <option value="SEV-4">SEV-4</option>
            </select>

            {/* Category filter */}
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-black/40 border border-slate-700 text-xs font-mono text-slate-300 outline-none"
            >
              <option value="all">All Root Cause Categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <span>Sort by:</span>
            <button
              onClick={() => setSelectedSort('date')}
              className={`px-2.5 py-1 rounded border text-xs transition-colors ${
                selectedSort === 'date'
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-semibold'
                  : 'border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Date
            </button>
            <button
              onClick={() => setSelectedSort('time')}
              className={`px-2.5 py-1 rounded border text-xs transition-colors ${
                selectedSort === 'time'
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-semibold'
                  : 'border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Resolution Time
            </button>
          </div>
        </div>
      </div>

      {/* Memory Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.length === 0 ? (
          <div className="col-span-full rounded-xl border border-slate-800 bg-[#0d1322] p-12 text-center text-slate-400 font-mono text-xs">
            No memories match your search criteria.
          </div>
        ) : (
          filtered.map(memory => (
            <div
              key={memory.id}
              className={`rounded-xl border p-4.5 flex flex-col justify-between transition-all bg-[#090e1a]/90 hover:border-cyan-500/50 hover:bg-[#0c1222] shadow-md group ${
                memory.isLiveLearned
                  ? 'border-emerald-500/40 ring-1 ring-emerald-500/30'
                  : 'border-slate-800'
              }`}
            >
              <div className="space-y-3">
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                      {memory.service}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800/80 text-slate-400">
                      {memory.rootCauseCategory}
                    </span>
                  </div>
                  <SeverityBadge severity={memory.severity} size="sm" />
                </div>

                {/* Title */}
                <h3 className="font-semibold text-sm text-slate-100 group-hover:text-cyan-300 font-sans transition-colors line-clamp-2">
                  {memory.incidentTitle}
                </h3>

                {/* Live Learned Tag */}
                {memory.isLiveLearned && (
                  <div className="inline-flex items-center gap-1 text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/40">
                    <Sparkles className="w-3 h-3 text-emerald-400 animate-pulse" />
                    <span>Learned from Live Incident</span>
                  </div>
                )}

                {/* Root Cause & Resolution */}
                <div className="space-y-2 pt-2 border-t border-slate-800/80 text-xs font-sans">
                  <div>
                    <span className="text-[10px] font-mono uppercase text-slate-400 font-semibold block">
                      Root Cause:
                    </span>
                    <p className="text-slate-300 leading-relaxed line-clamp-2">
                      {memory.rootCause}
                    </p>
                  </div>

                  <div>
                    <span className="text-[10px] font-mono uppercase text-cyan-400 font-semibold block">
                      Resolution:
                    </span>
                    <p className="text-slate-300 leading-relaxed line-clamp-2">
                      {memory.resolution}
                    </p>
                  </div>
                </div>

                {/* Runbook Tag */}
                <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-400">
                  <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="truncate">{memory.runbook}</span>
                </div>
              </div>

              {/* Card Footer */}
              <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1 text-slate-300">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    {memory.timeToResolutionMinutes}m
                  </span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Success
                  </span>
                </div>

                <button
                  onClick={() => setSelectedPostMortem(memory)}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 text-[11px] font-mono hover:underline cursor-pointer"
                >
                  <span>Post-Mortem</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Post-Mortem Inspection Modal */}
      <PostMortemModal
        isOpen={!!selectedPostMortem}
        onClose={() => setSelectedPostMortem(null)}
        memory={selectedPostMortem}
      />
    </div>
  );
};
