import React, { useState } from 'react';
import {
  FileText,
  ScanText,
  Binary,
  Database,
  BrainCircuit,
  Wrench,
  CheckSquare,
  Save,
  ArrowDown,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Layers,
  Cpu
} from 'lucide-react';

export const ArchitectureView: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState<number>(0);

  const pipelineStages = [
    {
      id: 0,
      title: '1. Incident & Logs Ingestion',
      subtitle: 'Raw error streams, traces & alerts',
      icon: FileText,
      color: 'from-rose-500/20 to-orange-500/20 border-rose-500/40 text-rose-300',
      description:
        'Captures incoming PagerDuty alerts, Datadog metrics, and unhandled exception traces from production microservices (e.g. SQLAlchemy QueuePool limit exceeded).',
      details: [
        'Parses service name, environment, and error stack traces',
        'Extracts categorical error tokens (e.g. timeout, deadlock, OOM)',
        'Normalizes timestamps, log payloads, and user impact descriptors'
      ]
    },
    {
      id: 1,
      title: '2. Incident Analyzer & Token Normalizer',
      subtitle: 'Feature extraction & signature isolation',
      icon: ScanText,
      color: 'from-amber-500/20 to-yellow-500/20 border-amber-500/40 text-amber-300',
      description:
        'Normalizes unstructured logs into standardized SRE feature vectors, stripping noisy variable payloads while isolating error signatures.',
      details: [
        'Token frequency ranking with SRE domain term weighting',
        'Extracts root exception signatures (e.g. TimeoutError: QueuePool limit)',
        'Generates unified incident query representation'
      ]
    },
    {
      id: 2,
      title: '3. Vector Embedding Generation',
      subtitle: '384-dimensional dense projection',
      icon: Binary,
      color: 'from-cyan-500/20 to-blue-500/20 border-cyan-500/40 text-cyan-300',
      description:
        'Projects the normalized incident tokens into a continuous 384-dimensional dense semantic embedding space with L2-normalization for cosine distance computations.',
      details: [
        'Combines hashed n-gram token space with domain attention tensors',
        'Guarantees semantic closeness between related failure modes',
        'Enables sub-millisecond similarity scoring across historical datasets'
      ]
    },
    {
      id: 3,
      title: '4. Vector Database & Historical Memory',
      subtitle: 'Cosine similarity & hybrid Top-K retrieval',
      icon: Database,
      color: 'from-purple-500/20 to-indigo-500/20 border-purple-500/40 text-purple-300',
      description:
        'Performs Top-K retrieval against the organizational vector memory store, identifying past incidents with identical symptoms and verified successful resolutions.',
      details: [
        'Cosine similarity: cos(θ) = (A · B) / (||A|| ||B||)',
        'Hybrid lexical BM25 token bonus for exact service & error matches',
        'Calculates calibrated match percentages (e.g. 94% similarity)'
      ]
    },
    {
      id: 4,
      title: '5. LLM Orchestrator (RAG + Reasoning)',
      subtitle: 'Grounded synthesis via Gemini 3.8 Flash',
      icon: BrainCircuit,
      color: 'from-indigo-500/20 to-violet-500/20 border-indigo-500/40 text-indigo-300',
      description:
        'Constructs a strictly grounded RAG prompt containing the current incident logs alongside retrieved historical resolutions, invoking Gemini 3.8 Flash with structured schema constraints.',
      details: [
        'Rule-enforced SRE system prompt preventing hallucination',
        'Strict evidence separation: Observed vs. Historical vs. AI Hypothesis',
        'Generates user-facing "Why This Recommendation?" explanation'
      ]
    },
    {
      id: 5,
      title: '6. Actionable Remediation Plan',
      subtitle: '4-stage action plan & executable runbook',
      icon: Wrench,
      color: 'from-emerald-500/20 to-teal-500/20 border-emerald-500/40 text-emerald-300',
      description:
        'Delivers a staged recovery workflow: Stage 1 Immediate Workaround, Stage 2 Diagnostic Isolation, Stage 3 Permanent Fix, and Stage 4 Post-Recovery Verification.',
      details: [
        'Selects verified production runbook (e.g. DB Connection Pool Recovery)',
        'Provides copyable CLI commands with safe execution disclaimers',
        'Offers interactive in-browser simulation sandbox to preview mitigation'
      ]
    },
    {
      id: 6,
      title: '7. Engineer Feedback & Post-Mortem',
      subtitle: 'Human-in-the-loop validation',
      icon: CheckSquare,
      color: 'from-blue-500/20 to-cyan-500/20 border-blue-500/40 text-blue-300',
      description:
        'When the incident is resolved, the on-call engineer records what actually fixed the outage, rates AI utility, and documents key architectural takeaways.',
      details: [
        'Captures exact resolution steps & verified root cause',
        'Records actual time to resolution (MTTR)',
        'Validates or corrects AI hypotheses with ground truth'
      ]
    },
    {
      id: 7,
      title: '8. New Memory Object & Vector Indexing',
      subtitle: 'Continuous learning feedback loop',
      icon: Save,
      color: 'from-teal-500/20 to-emerald-500/20 border-teal-500/40 text-teal-300',
      description:
        'Generates a new vector embedding for the completed post-mortem and inserts it into the Vector Database. The next time a similar failure occurs, this memory is retrieved!',
      details: [
        'Closes the central product loop: Incident → Memory → Remediation → Learn',
        'New memory immediately available for subsequent vector similarity queries',
        'Tagged with "Learned from Live Incident" badge in future incident views'
      ]
    }
  ];

  const active = pipelineStages[selectedNode];

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-indigo-950/70 text-indigo-300 border border-indigo-800/40 uppercase font-semibold">
            System Architecture
          </span>
        </div>
        <h2 className="text-xl md:text-2xl font-bold text-slate-100 font-sans tracking-tight">
          Retrieval-Augmented Incident Response Architecture
        </h2>
        <p className="text-xs text-slate-400 font-sans max-w-3xl">
          Visual representation of the central autonomous learning loop: New Incident → Retrieve Memory → Analyze → Recommend → Resolve → Learn → Improve Future Responses.
        </p>
      </div>

      {/* Main Flow Diagram */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Pipeline Nodes */}
        <div className="lg:col-span-7 space-y-2.5">
          {pipelineStages.map((stage, idx) => {
            const Icon = stage.icon;
            const isSelected = selectedNode === stage.id;
            return (
              <React.Fragment key={stage.id}>
                <div
                  onClick={() => setSelectedNode(stage.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? `bg-slate-900 border-cyan-400 shadow-lg shadow-cyan-950/40 ring-1 ring-cyan-500/30`
                      : 'bg-[#0d1322] border-slate-800 hover:border-slate-700 hover:bg-[#0f172a]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-lg border flex items-center justify-center bg-gradient-to-br ${stage.color}`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-xs text-slate-100 font-sans">
                        {stage.title}
                      </h4>
                      <p className="text-[11px] text-slate-400 font-mono">
                        {stage.subtitle}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                      isSelected
                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/50'
                        : 'text-slate-400'
                    }`}
                  >
                    Step {idx + 1}
                  </span>
                </div>

                {/* Connecting Arrow */}
                {idx < pipelineStages.length - 1 && (
                  <div className="flex justify-center py-0.5">
                    <ArrowDown className="w-3.5 h-3.5 text-slate-700 animate-pulse" />
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* Right Side: Deep-Dive Inspector */}
        <div className="lg:col-span-5 space-y-4">
          <div className="sticky top-20 rounded-2xl border border-slate-800 bg-[#0d1322] p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-mono font-semibold text-cyan-400 uppercase tracking-wider">
                Stage Deep-Dive
              </span>
              <span className="text-xs font-mono text-slate-400">
                Node {active.id + 1} of 8
              </span>
            </div>

            <div className="space-y-2">
              <h3 className="text-base font-bold text-slate-100 font-sans">
                {active.title}
              </h3>
              <p className="text-xs text-slate-300 font-sans leading-relaxed">
                {active.description}
              </p>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800">
              <span className="text-[11px] font-mono uppercase text-slate-400 font-semibold block">
                Technical Highlights:
              </span>
              <ul className="space-y-1.5 text-xs text-slate-300 font-sans">
                {active.details.map((detail, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-cyan-400 shrink-0 font-bold">•</span>
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Vector math highlight if stage is vector related */}
            {active.id === 3 && (
              <div className="rounded-lg bg-black/60 border border-purple-900/40 p-3 font-mono text-[11px] text-purple-300 space-y-1">
                <span className="text-purple-400 font-bold block">Cosine Similarity Formula:</span>
                <code>cos(θ) = ∑(A_i · B_i) / (√∑A_i² · √∑B_i²)</code>
                <p className="text-slate-400 text-[10px] pt-1">
                  Evaluated across 384 dimensions with BM25 entity weighting.
                </p>
              </div>
            )}

            {/* Continuous Learning Callout if step 7 */}
            {active.id === 7 && (
              <div className="rounded-lg bg-emerald-950/30 border border-emerald-800/40 p-3 font-mono text-[11px] text-emerald-300 space-y-1">
                <span className="font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  Self-Reinforcing Knowledge Loop:
                </span>
                <p className="text-slate-300 text-xs font-sans leading-relaxed">
                  Every incident resolved by your engineering team directly enriches the agent’s organizational memory. The system gets smarter with every production outage.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
