import React from 'react';
import { Incident } from '../../types/incident';
import { DashboardMetrics } from '../../lib/api';
import { DEMO_PRESETS } from '../../server/seedData';
import { SeverityBadge } from '../common/SeverityBadge';
import { StatusBadge } from '../common/StatusBadge';
import {
  ShieldAlert,
  PlusCircle,
  Database,
  Clock,
  BookOpen,
  Sparkles,
  ArrowRight,
  Zap,
  Activity,
  Server,
  CheckCircle2,
  AlertTriangle,
  Radio,
  Cpu
} from 'lucide-react';

interface DashboardViewProps {
  metrics: DashboardMetrics | null;
  recentIncidents: Incident[];
  onNewIncident: () => void;
  onSelectIncident: (incident: Incident) => void;
  onSelectDemo: (demoPreset: (typeof DEMO_PRESETS)[0]) => void;
  onExploreMemory: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  metrics,
  recentIncidents,
  onNewIncident,
  onSelectIncident,
  onSelectDemo,
  onExploreMemory
}) => {
  const serviceHealth = [
    { name: 'payment-api', status: 'degraded', p99: '10.2s', errorRate: '48.2%', env: 'Production' },
    { name: 'order-service', status: 'healthy', p99: '142ms', errorRate: '0.01%', env: 'Production' },
    { name: 'auth-service', status: 'healthy', p99: '64ms', errorRate: '0.00%', env: 'Production' },
    { name: 'billing-worker', status: 'healthy', p99: '210ms', errorRate: '0.02%', env: 'Production' },
    { name: 'postgres-primary', status: 'healthy', p99: '12ms', errorRate: '0.00%', env: 'Production' },
    { name: 'redis-cluster', status: 'healthy', p99: '2ms', errorRate: '0.00%', env: 'Production' }
  ];

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Banner with Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#0d1629] via-[#0b101c] to-[#080d18] border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="space-y-2 z-10">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-cyan-950/70 border border-cyan-800/50 text-[11px] font-mono text-cyan-300">
            <Radio className="w-3 h-3 text-cyan-400 animate-pulse" />
            <span>AI SRE Incident Memory Engine Online</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-slate-100 font-sans tracking-tight">
            Incident Response Agent
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 font-sans max-w-2xl leading-relaxed">
            Autonomous SRE copilot with persistent historical memory. Ingests failure logs, matches vectors across past outages, explains recommendations with verified precedents, and learns from post-mortems.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 z-10 shrink-0">
          <button
            onClick={onNewIncident}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-indigo-600 to-violet-600 hover:from-cyan-400 hover:via-indigo-500 hover:to-violet-500 text-white font-semibold text-sm shadow-xl shadow-cyan-950/50 transition-all cursor-pointer font-sans"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ New Incident</span>
          </button>
        </div>

        {/* Ambient background blur */}
        <div className="absolute right-0 top-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Primary Hackathon Demo Launcher Banner */}
      <div className="rounded-xl border border-indigo-500/40 bg-[#0c1326] p-4 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400 fill-current" />
            <h3 className="font-semibold text-xs font-mono uppercase tracking-wider text-slate-200">
              Interactive Hackathon Demo Scenarios
            </h3>
          </div>
          <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
            Instant 3-Min Walkthrough
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {DEMO_PRESETS.map((demo, idx) => (
            <div
              key={demo.id}
              onClick={() => onSelectDemo(demo)}
              className="p-3.5 rounded-lg border border-slate-800 hover:border-cyan-500/50 bg-[#080d1a] hover:bg-[#0d1424] transition-all cursor-pointer group flex flex-col justify-between space-y-2"
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="text-cyan-400 font-semibold">Scenario {idx + 1}</span>
                  <span className="px-1.5 py-0.5 rounded bg-rose-950/60 text-rose-300 border border-rose-800/40">
                    {demo.severity}
                  </span>
                </div>
                <h4 className="font-semibold text-xs text-slate-200 group-hover:text-cyan-300 font-sans line-clamp-2">
                  {demo.label}
                </h4>
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/60">
                <span>{demo.service}</span>
                <span className="text-cyan-400 group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Run Demo <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Core SRE Metrics Grid (Requirement 30) */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
        {/* Total Incidents */}
        <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Total Incidents</span>
            <ShieldAlert className="w-4 h-4 text-slate-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100">
            {metrics?.totalIncidents ?? 142}
          </div>
          <div className="text-[10px] font-mono text-slate-400">
            Historical + Active
          </div>
        </div>

        {/* Resolved Incidents */}
        <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Resolved</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {metrics?.resolvedIncidents ?? 136}
          </div>
          <div className="text-[10px] font-mono text-emerald-400/80">
            Post-mortems indexed
          </div>
        </div>

        {/* Average Resolution Time */}
        <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Avg MTTR</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-300">
            {metrics?.averageResolutionTime ?? '18m'}
          </div>
          <div className="text-[10px] font-mono text-slate-400">
            -42% with AI memory
          </div>
        </div>

        {/* Historical Memories */}
        <div
          onClick={onExploreMemory}
          className="rounded-xl border border-slate-800 hover:border-cyan-500/50 bg-[#0d1322] p-4 space-y-1 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Vector Memories</span>
            <Database className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-purple-300">
            {metrics?.historicalMemories ?? 128}
          </div>
          <div className="text-[10px] font-mono text-purple-400/80">
            Click to explore →
          </div>
        </div>

        {/* Successful Runbooks */}
        <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>Runbooks</span>
            <BookOpen className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-300">
            {metrics?.successfulRunbooks ?? 42}
          </div>
          <div className="text-[10px] font-mono text-slate-400">
            Verified SOP catalog
          </div>
        </div>

        {/* AI Assisted Resolutions */}
        <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>AI Assist Rate</span>
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-400">
            {metrics?.aiAssistedResolutionRate ?? '87%'}
          </div>
          <div className="text-[10px] font-mono text-cyan-400/80">
            Memory RAG precision
          </div>
        </div>
      </div>

      {/* Main Grid: Active Incidents & System Health */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Recent Incidents */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-cyan-400" />
              <h3 className="font-semibold text-sm text-slate-100 font-sans tracking-wide">
                Recent Incident Activity
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-400">
              {recentIncidents.length} Monitored
            </span>
          </div>

          <div className="space-y-3">
            {recentIncidents.map(inc => (
              <div
                key={inc.id}
                onClick={() => onSelectIncident(inc)}
                className="rounded-xl border border-slate-800 hover:border-cyan-500/50 bg-[#0d1322] hover:bg-[#0f172a] p-4 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <SeverityBadge severity={inc.severity} size="sm" />
                    <StatusBadge status={inc.status} />
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      {inc.service}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {inc.environment}
                    </span>
                  </div>

                  <h4 className="font-semibold text-sm text-slate-100 group-hover:text-cyan-300 font-sans transition-colors">
                    {inc.title}
                  </h4>

                  <p className="text-xs text-slate-400 line-clamp-1 font-sans">
                    {inc.description}
                  </p>

                  {inc.similarIncidents && inc.similarIncidents.length > 0 && (
                    <div className="text-[11px] font-mono text-cyan-400 flex items-center gap-1 pt-1">
                      <span>✓ {inc.similarIncidents.length} historical memories retrieved</span>
                      <span>• Top match: {Math.round((inc.similarIncidents[0]?.similarityScore || 0) * 100)}%</span>
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  className="px-3.5 py-1.5 rounded-lg border border-slate-700 group-hover:border-cyan-500/40 bg-slate-800/80 group-hover:bg-cyan-950/40 text-xs font-mono text-slate-300 group-hover:text-cyan-300 flex items-center gap-1.5 transition-colors self-end sm:self-auto shrink-0"
                >
                  <span>Review Analysis</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Infrastructure Health & AI Insights */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              <h3 className="font-semibold text-sm text-slate-100 font-sans tracking-wide">
                Production Services
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-400">6 Monitored</span>
          </div>

          <div className="rounded-xl border border-slate-800 bg-[#0d1322] p-4 space-y-3">
            {serviceHealth.map(svc => (
              <div
                key={svc.name}
                className="flex items-center justify-between py-2 border-b border-slate-800/60 last:border-0 text-xs font-mono"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        svc.status === 'degraded' ? 'bg-rose-500 animate-ping' : 'bg-emerald-400'
                      }`}
                    />
                    <span className="font-semibold text-slate-200">{svc.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">{svc.env}</span>
                </div>

                <div className="text-right">
                  <div
                    className={`font-semibold ${
                      svc.status === 'degraded' ? 'text-rose-400' : 'text-slate-300'
                    }`}
                  >
                    p99: {svc.p99}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    err: {svc.errorRate}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* AI Memory Snapshot */}
          <div className="rounded-xl border border-indigo-900/50 bg-gradient-to-br from-[#0d1326] to-[#080d1a] p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-purple-400" />
                <h4 className="font-semibold text-xs font-mono uppercase text-slate-200">
                  Vector Memory Engine
                </h4>
              </div>
              <span className="text-[10px] font-mono text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-800/40">
                Dense 384-dim
              </span>
            </div>

            <p className="text-xs font-sans text-slate-300 leading-relaxed">
              When an engineer resolves an incident, the post-mortem is embedded and indexed. Subsequent incidents in the same failure domain will immediately retrieve it.
            </p>

            <button
              onClick={onExploreMemory}
              className="w-full py-2 rounded-lg border border-purple-500/40 hover:border-purple-400 bg-purple-950/30 hover:bg-purple-900/40 text-xs font-mono text-purple-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>Browse 15 Historical Memories</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
