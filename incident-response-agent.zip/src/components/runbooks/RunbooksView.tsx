import React, { useState } from 'react';
import { RecommendedRunbook } from '../../types/incident';
import { SimulationModal } from '../incidents/SimulationModal';
import { BookOpen, Copy, Check, Play, Terminal, ShieldCheck, AlertTriangle } from 'lucide-react';

interface RunbooksViewProps {
  runbooks: RecommendedRunbook[];
}

export const RunbooksView: React.FC<RunbooksViewProps> = ({ runbooks }) => {
  const [activeSimulation, setActiveSimulation] = useState<RecommendedRunbook | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-amber-950/70 text-amber-300 border border-amber-800/40 uppercase font-semibold">
              Verified SRE Procedures
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-100 font-sans tracking-tight">
            Automated Runbook Catalog
          </h2>
          <p className="text-xs text-slate-400 font-sans">
            Standard operating procedures indexed from historical incident post-mortems with verified remediation command scripts.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3.5 py-1.5 rounded-lg border border-slate-700 bg-slate-800/80 text-xs font-mono text-slate-300">
            {runbooks.length} Production Runbooks
          </span>
        </div>
      </div>

      {/* Runbook Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {runbooks.map(rb => (
          <div
            key={rb.id}
            className="rounded-xl border border-slate-800 bg-[#0d1322] p-5 shadow-lg flex flex-col justify-between space-y-4 hover:border-cyan-500/40 transition-colors"
          >
            <div className="space-y-3">
              {/* Header */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center">
                    <BookOpen className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-100 text-sm font-sans tracking-wide">
                      {rb.name}
                    </h3>
                    <span className="text-[11px] font-mono text-cyan-400">
                      Target: {rb.targetService}
                    </span>
                  </div>
                </div>

                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-950/60 text-emerald-400 border border-emerald-500/40 shrink-0">
                  {Math.round(rb.successRate * 100)}% Success
                </span>
              </div>

              <p className="text-xs font-sans text-slate-300 leading-relaxed">
                {rb.description}
              </p>

              {/* Warning note */}
              <div className="rounded-lg bg-amber-950/20 border border-amber-800/30 p-2.5 flex items-start gap-2 text-[11px] text-amber-300/90 font-sans">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>{rb.warning}</span>
              </div>

              {/* Steps list */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[11px] font-mono text-slate-400 font-semibold uppercase block">
                  Procedure Steps:
                </span>
                <ul className="space-y-1 text-xs text-slate-300 font-sans">
                  {rb.steps.map((st, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-cyan-400 font-mono text-[11px]">{idx + 1}.</span>
                      <span>{st}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Commands preview */}
              <div className="space-y-1.5 pt-2">
                <span className="text-[11px] font-mono text-slate-400 font-semibold uppercase block">
                  Remediation Commands:
                </span>
                <div className="space-y-1.5">
                  {rb.commands.map((cmd, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between bg-black/60 rounded px-3 py-1.5 font-mono text-xs text-cyan-300 border border-slate-800"
                    >
                      <code className="truncate select-all">{cmd}</code>
                      <button
                        onClick={() => handleCopy(`${rb.id}-${idx}`, cmd)}
                        className="ml-2 text-slate-400 hover:text-white p-1 rounded"
                      >
                        {copiedId === `${rb.id}-${idx}` ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Run in simulation button */}
            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setActiveSimulation(rb)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-mono text-xs font-semibold shadow-md shadow-cyan-950 transition-all cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Test Run in Simulation</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Simulation Modal */}
      {activeSimulation && (
        <SimulationModal
          isOpen={!!activeSimulation}
          onClose={() => setActiveSimulation(null)}
          service={activeSimulation.targetService}
          runbookName={activeSimulation.name}
          commands={activeSimulation.commands}
          onSimulationCompleted={() => {}}
        />
      )}
    </div>
  );
};
