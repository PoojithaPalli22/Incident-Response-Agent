import React, { useState, useEffect } from 'react';
import { Incident, IncidentMemory, RecommendedRunbook, AgentActivityStep, Severity, Environment, AlertSource } from './types/incident';
import { api, DashboardMetrics } from './lib/api';
import { Header } from './components/common/Header';
import { Sidebar, NavTab } from './components/common/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { NewIncidentView } from './components/incidents/NewIncidentView';
import { IncidentDetailView } from './components/incidents/IncidentDetailView';
import { IncidentListView } from './components/incidents/IncidentListView';
import { MemoryExplorerView } from './components/memory/MemoryExplorerView';
import { RunbooksView } from './components/runbooks/RunbooksView';
import { ArchitectureView } from './components/architecture/ArchitectureView';
import { SettingsView } from './components/settings/SettingsView';

export function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [memories, setMemories] = useState<IncidentMemory[]>([]);
  const [runbooks, setRunbooks] = useState<RecommendedRunbook[]>([]);
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [activitySteps, setActivitySteps] = useState<AgentActivityStep[]>([]);

  // Load initial data
  const loadAllData = async () => {
    try {
      const [fetchedIncidents, fetchedMemories, fetchedRunbooks, fetchedMetrics] = await Promise.all([
        api.getIncidents(),
        api.getMemories(),
        api.getRunbooks(),
        api.getMetrics()
      ]);
      setIncidents(fetchedIncidents);
      setMemories(fetchedMemories);
      setRunbooks(fetchedRunbooks);
      setMetrics(fetchedMetrics);

      // Default selected incident to first incident if available
      if (fetchedIncidents.length > 0 && !selectedIncident) {
        setSelectedIncident(fetchedIncidents[0]);
      }
    } catch (err) {
      console.error('Error loading data:', err);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // Handle New Incident creation & immediate analysis
  const handleCreateIncident = async (incidentData: {
    title: string;
    severity: Severity;
    service: string;
    environment: Environment;
    description: string;
    logs: string;
    alertSource: AlertSource;
  }) => {
    setIsAnalyzing(true);
    setActivitySteps([]);
    try {
      // 1. Create incident
      const newInc = await api.createIncident(incidentData);

      // 2. Trigger AI RAG analysis
      const analysisResult = await api.analyzeIncident(newInc.id);

      // 3. Update state
      setIncidents(prev => [analysisResult.incident, ...prev.filter(i => i.id !== newInc.id)]);
      setSelectedIncident(analysisResult.incident);
      setActivitySteps(analysisResult.activitySteps || []);

      // Reload metrics & memories
      const [m, mems] = await Promise.all([api.getMetrics(), api.getMemories()]);
      setMetrics(m);
      setMemories(mems);

      // Switch view to details
      setCurrentTab('incidents');
    } catch (err) {
      console.error('Failed to create and analyze incident:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Re-run analysis on an existing incident
  const handleReanalyzeIncident = async () => {
    if (!selectedIncident) return;
    setIsAnalyzing(true);
    try {
      const analysisResult = await api.analyzeIncident(selectedIncident.id);
      setSelectedIncident(analysisResult.incident);
      setActivitySteps(analysisResult.activitySteps || []);
      setIncidents(prev => prev.map(i => (i.id === selectedIncident.id ? analysisResult.incident : i)));
    } catch (err) {
      console.error('Failed to re-analyze incident:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Toggle remediation step
  const handleToggleStep = async (stepId: string, completed: boolean) => {
    if (!selectedIncident) return;
    try {
      const updated = await api.toggleStep(selectedIncident.id, stepId, completed);
      setSelectedIncident(updated);
      setIncidents(prev => prev.map(i => (i.id === updated.id ? updated : i)));
    } catch (err) {
      console.error('Failed to toggle step:', err);
    }
  };

  // Run runbook in simulation mode
  const handleSimulate = async () => {
    if (!selectedIncident) return;
    try {
      const result = await api.simulateRunbook(selectedIncident.id);
      setSelectedIncident(result.incident);
      setIncidents(prev => prev.map(i => (i.id === result.incident.id ? result.incident : i)));
      const m = await api.getMetrics();
      setMetrics(m);
    } catch (err) {
      console.error('Failed to simulate runbook:', err);
    }
  };

  // Mark incident as resolved & index into vector memory
  const handleResolveIncident = async (data: any) => {
    if (!selectedIncident) return;
    try {
      const result = await api.resolveIncident(selectedIncident.id, data);
      setSelectedIncident(result.incident);
      setIncidents(prev => prev.map(i => (i.id === result.incident.id ? result.incident : i)));

      // Reload memories & metrics to show the newly added memory!
      const [updatedMemories, updatedMetrics] = await Promise.all([
        api.getMemories(),
        api.getMetrics()
      ]);
      setMemories(updatedMemories);
      setMetrics(updatedMetrics);
    } catch (err) {
      console.error('Failed to resolve incident:', err);
    }
  };

  // Reset to initial seed state
  const handleResetData = async () => {
    try {
      await api.resetData();
      await loadAllData();
      setSelectedIncident(null);
      setCurrentTab('dashboard');
    } catch (err) {
      console.error('Failed to reset data:', err);
    }
  };

  const activeIncidentsCount = incidents.filter(i => i.status !== 'resolved').length;

  return (
    <div className="flex h-screen bg-[#070b12] text-slate-100 overflow-hidden font-sans">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={tab => {
          setCurrentTab(tab);
          if (tab === 'new-incident') {
            // Keep selected incident untouched
          }
        }}
        activeIncidentsCount={activeIncidentsCount}
        memoriesCount={memories.length}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header
          onNewIncident={() => setCurrentTab('new-incident')}
          onResetData={handleResetData}
          memoriesCount={memories.length}
        />

        {/* Scrollable Viewport */}
        <main className="flex-1 overflow-y-auto px-6 py-6 lg:px-8">
          {/* Dashboard Tab */}
          {currentTab === 'dashboard' && (
            <DashboardView
              metrics={metrics}
              recentIncidents={incidents}
              onNewIncident={() => setCurrentTab('new-incident')}
              onSelectIncident={inc => {
                setSelectedIncident(inc);
                setCurrentTab('incidents');
              }}
              onSelectDemo={demoPreset => {
                setCurrentTab('new-incident');
              }}
              onExploreMemory={() => setCurrentTab('memory')}
            />
          )}

          {/* New Incident Tab */}
          {currentTab === 'new-incident' && (
            <NewIncidentView
              onSubmit={handleCreateIncident}
              isAnalyzing={isAnalyzing}
            />
          )}

          {/* Incidents Tab: List or Detail */}
          {currentTab === 'incidents' && (
            <>
              {selectedIncident ? (
                <IncidentDetailView
                  incident={selectedIncident}
                  activitySteps={activitySteps}
                  onBack={() => setSelectedIncident(null)}
                  onToggleStep={handleToggleStep}
                  onSimulate={handleSimulate}
                  onResolve={handleResolveIncident}
                  onReanalyze={handleReanalyzeIncident}
                  isAnalyzing={isAnalyzing}
                />
              ) : (
                <IncidentListView
                  incidents={incidents}
                  onSelectIncident={inc => setSelectedIncident(inc)}
                  onNewIncident={() => setCurrentTab('new-incident')}
                />
              )}
            </>
          )}

          {/* Memory Explorer Tab */}
          {currentTab === 'memory' && (
            <MemoryExplorerView memories={memories} />
          )}

          {/* Runbooks Catalog Tab */}
          {currentTab === 'runbooks' && (
            <RunbooksView runbooks={runbooks} />
          )}

          {/* Architecture Visualization Tab */}
          {currentTab === 'architecture' && (
            <ArchitectureView />
          )}

          {/* Settings Tab */}
          {currentTab === 'settings' && (
            <SettingsView
              onResetData={handleResetData}
              memoriesCount={memories.length}
            />
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
